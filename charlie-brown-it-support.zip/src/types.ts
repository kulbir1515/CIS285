export type NavPage =
  | 'home'
  | 'hardware'
  | 'software'
  | 'troubleshooting'
  | 'faqs'
  | 'tutorials'
  | 'downloads'
  | 'vendors'
  | 'contact';

export interface NavItem {
  id: NavPage;
  label: string;
  iconName: string;
  description: string;
}

export interface SupportArticle {
  id: string;
  title: string;
  category: 'hardware' | 'software' | 'troubleshooting' | 'tutorial' | 'faq' | 'resource';
  subcategory?: string;
  summary: string;
  targetPage: NavPage;
  steps?: string[];
  tips?: string[];
  difficulty?: 'Easy' | 'Intermediate' | 'Advanced';
  timeMinutes?: number;
  tags: string[];
}

export interface HardwareIssue {
  id: string;
  title: string;
  icon: string;
  symptoms: string[];
  quickCheck: string;
  steps: {
    title: string;
    description: string;
    caution?: string;
  }[];
  proTip: string;
  escalation: string;
}

export interface SoftwareIssue {
  id: string;
  title: string;
  app: string;
  icon: string;
  symptoms: string[];
  steps: {
    title: string;
    description: string;
  }[];
  proTip: string;
  alternativeSolution?: string;
}

export interface TroubleshootingTopic {
  id: string;
  title: string;
  urgency: 'Low' | 'Medium' | 'High' | 'Critical';
  icon: string;
  commonCauses: string[];
  primarySteps: {
    step: number;
    title: string;
    details: string;
  }[];
  advancedSteps?: {
    title: string;
    details: string;
  }[];
  warning?: string;
}

export interface DiagnosticNode {
  id: string;
  question: string;
  options: {
    label: string;
    nextNodeId?: string;
    solution?: {
      title: string;
      description: string;
      steps: string[];
      escalateNote?: string;
    };
  }[];
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: 'General' | 'Hardware' | 'Software' | 'Accounts & Access' | 'Network & Wi-Fi' | 'Security';
  tags: string[];
}

export interface TutorialItem {
  id: string;
  title: string;
  provider: string;
  url: string;
  category: string;
  summary: string;
  description: string;
  applicationsCovered: string[];
  skillLevel: 'Beginner' | 'Intermediate' | 'All Levels';
  accessType: string;
  badge?: string;
  featured?: boolean;
}

export interface ScreenshotPlaceholder {
  id: string;
  label: string;
  description: string;
  aspectRatio?: string;
}

export interface TutorialStep {
  stepNumber: number;
  title: string;
  instruction: string;
  details?: string[];
  screenshotPlaceholder: ScreenshotPlaceholder;
  proTip?: string;
  caution?: string;
}

export interface TroubleshootingTip {
  problem: string;
  solution: string;
}

export interface OfficialReference {
  title: string;
  source: string;
  url?: string;
  notes?: string;
}

export interface OriginalTutorial {
  id: string;
  title: string;
  summary: string;
  introduction: string;
  category: 'Windows Basics' | 'Troubleshooting' | 'Hardware Support' | 'Network Support';
  difficulty: 'Beginner' | 'Intermediate';
  estimatedTime: string;
  iconName: 'Camera' | 'Activity' | 'Printer' | 'Wifi';
  whatYouWillLearn: string[];
  requirements: string[];
  steps: TutorialStep[];
  expectedResult: string;
  commonProblems: TroubleshootingTip[];
  safetyReminders: string[];
  references: OfficialReference[];
}

export interface ResourceItem {
  id: string;
  title: string;
  category: 'CIS 285 Project' | 'Organization Policies' | 'Best Practices' | 'Glossary' | 'Shortcuts';
  description: string;
  content: string;
  extraList?: string[];
}

export interface DownloadItem {
  id: string;
  name: string;
  officialUrl: string;
  developer: string;
  category: string;
  os: string;
  licenseType: string;
  description: string;
  itSupportUseCases: string;
  keyFeatures?: string[];
  featured?: boolean;
}

export interface VendorItem {
  id: string;
  name: string;
  category: 'Hardware' | 'Software & Cloud' | 'Networking' | 'Printers';
  supportUrl: string;
  phone: string;
  hours: string;
  serviceTagPortal?: string;
  notes: string;
}

export interface SupportTicket {
  ticketId: string;
  fullName: string;
  email: string;
  department: string;
  category: string;
  priority: 'Low' | 'Medium' | 'High' | 'Urgent';
  subject: string;
  description: string;
  deviceType?: string;
  assetTag?: string;
  status: 'Open' | 'In Progress' | 'Pending Parts' | 'Resolved';
  createdAt: string;
  lastUpdated: string;
  assignedTechnician?: string;
}
