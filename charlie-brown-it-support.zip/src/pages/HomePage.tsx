import React, { useState } from 'react';
import {
  Search,
  HardDrive,
  AppWindow,
  AlertCircle,
  BookOpen,
  Headphones,
  Phone,
  MapPin,
  Clock,
  ChevronRight,
  Sparkles,
} from 'lucide-react';
import { NavPage } from '../types';
import {
  ORG_NAME,
  APP_TITLE,
  HELPDESK_PHONE,
  HELPDESK_LOCATION,
  HELPDESK_HOURS,
} from '../data/supportData';

interface HomePageProps {
  onNavigate: (page: NavPage, targetId?: string) => void;
  onOpenSearch: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  onNavigate,
  onOpenSearch,
}) => {
  const [searchInput, setSearchInput] = useState('');

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onOpenSearch();
  };

  return (
    <div className="space-y-10 pb-12">
      {/* Hero Welcome Banner */}
      <section className="relative bg-gradient-to-b from-blue-900 via-slate-900 to-slate-900 text-white rounded-3xl overflow-hidden shadow-xl border border-slate-800">
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none" />

        <div className="relative max-w-4xl mx-auto px-6 py-10 sm:py-14 text-center space-y-5">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-500/20 border border-blue-400/30 text-blue-300 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5 text-blue-400" />
            <span>Charlie Brown IT Support Portal • {ORG_NAME}</span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-tight">
            Welcome to{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-300 to-cyan-200">
              {APP_TITLE}
            </span>
          </h1>

          <p className="text-base sm:text-lg text-slate-300 max-w-2xl mx-auto font-normal leading-relaxed">
            Your central helpdesk for beginner-friendly troubleshooting guides, hardware and software assistance, and IT support.
          </p>

          {/* Search Bar */}
          <div className="max-w-xl mx-auto pt-2">
            <form
              onSubmit={handleSearchSubmit}
              className="relative flex items-center bg-white rounded-2xl shadow-xl p-1.5 border border-slate-200 text-slate-900"
            >
              <Search className="w-5 h-5 text-blue-600 ml-3 shrink-0" />
              <input
                id="hero-search-input"
                type="text"
                placeholder="Search troubleshooting guides, tutorials, or topics..."
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                onFocus={onOpenSearch}
                className="w-full px-3 py-2 text-sm sm:text-base focus:outline-hidden text-slate-900 placeholder:text-slate-400"
              />
              <button
                id="hero-search-button"
                type="submit"
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-semibold rounded-xl transition-colors shrink-0 shadow-xs"
              >
                Search
              </button>
            </form>

            {/* Quick Links */}
            <div className="flex flex-wrap items-center justify-center gap-2 mt-4 text-xs text-slate-400">
              <span className="font-medium text-slate-300">Quick links:</span>
              {[
                { label: 'Slow Computer', page: 'troubleshooting' as NavPage, id: 'tb-slow' },
                { label: 'Wi-Fi Reconnect', page: 'tutorials' as NavPage, id: 'wifi-reconnect' },
                { label: 'Printer Help', page: 'hardware' as NavPage, id: 'hw-printer' },
                { label: 'Error Screenshots', page: 'tutorials' as NavPage, id: 'error-screenshot' },
                { label: 'Contact IT', page: 'contact' as NavPage },
              ].map((chip) => (
                <button
                  key={chip.label}
                  onClick={() => onNavigate(chip.page, chip.id)}
                  className="px-2.5 py-1 bg-slate-800/80 hover:bg-blue-600 hover:text-white text-slate-300 rounded-md border border-slate-700 transition-colors"
                >
                  {chip.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 5 Core Support Category Shortcuts */}
      <section className="space-y-4">
        <div className="border-b border-slate-200 pb-3">
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">
            Support Categories
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Choose a section to view simple guides or get in touch with our team.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {/* 1. Hardware Support */}
          <button
            id="quick-card-hardware"
            onClick={() => onNavigate('hardware')}
            className="group p-5 bg-white rounded-2xl border border-slate-200 hover:border-blue-400 shadow-xs hover:shadow-md transition-all text-left flex flex-col justify-between"
          >
            <div>
              <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center mb-3 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                <HardDrive className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-slate-900 group-hover:text-blue-600 transition-colors text-sm sm:text-base">
                Hardware Support
              </h3>
              <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                Troubleshoot power issues, blank monitors, printers, keyboards, and mice.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center text-xs font-semibold text-blue-600 group-hover:translate-x-1 transition-transform">
              <span>View Hardware Guides</span>
              <ChevronRight className="w-4 h-4 ml-1" />
            </div>
          </button>

          {/* 2. Software Support */}
          <button
            id="quick-card-software"
            onClick={() => onNavigate('software')}
            className="group p-5 bg-white rounded-2xl border border-slate-200 hover:border-indigo-400 shadow-xs hover:shadow-md transition-all text-left flex flex-col justify-between"
          >
            <div>
              <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-3 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                <AppWindow className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-slate-900 group-hover:text-indigo-600 transition-colors text-sm sm:text-base">
                Software Support
              </h3>
              <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                Fix frozen applications, email problems, sign-in errors, and file saving.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center text-xs font-semibold text-indigo-600 group-hover:translate-x-1 transition-transform">
              <span>View Software Guides</span>
              <ChevronRight className="w-4 h-4 ml-1" />
            </div>
          </button>

          {/* 3. Troubleshooting */}
          <button
            id="quick-card-troubleshooting"
            onClick={() => onNavigate('troubleshooting')}
            className="group p-5 bg-white rounded-2xl border border-slate-200 hover:border-amber-400 shadow-xs hover:shadow-md transition-all text-left flex flex-col justify-between"
          >
            <div>
              <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center mb-3 group-hover:bg-amber-600 group-hover:text-white transition-colors">
                <AlertCircle className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-slate-900 group-hover:text-amber-600 transition-colors text-sm sm:text-base">
                Troubleshooting
              </h3>
              <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                Simple solutions for slow computers, dropped Wi-Fi, login errors, and blank screens.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center text-xs font-semibold text-amber-600 group-hover:translate-x-1 transition-transform">
              <span>View Common Issues</span>
              <ChevronRight className="w-4 h-4 ml-1" />
            </div>
          </button>

          {/* 4. Tutorials */}
          <button
            id="quick-card-tutorials"
            onClick={() => onNavigate('tutorials')}
            className="group p-5 bg-white rounded-2xl border border-slate-200 hover:border-purple-400 shadow-xs hover:shadow-md transition-all text-left flex flex-col justify-between"
          >
            <div>
              <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center mb-3 group-hover:bg-purple-600 group-hover:text-white transition-colors">
                <BookOpen className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-slate-900 group-hover:text-purple-600 transition-colors text-sm sm:text-base">
                Our Tutorials
              </h3>
              <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                Step-by-step guides created by our team for screenshots, slow PCs, and Wi-Fi.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center text-xs font-semibold text-purple-600 group-hover:translate-x-1 transition-transform">
              <span>Read Team Guides</span>
              <ChevronRight className="w-4 h-4 ml-1" />
            </div>
          </button>

          {/* 5. Contact Support */}
          <button
            id="quick-card-contact"
            onClick={() => onNavigate('contact')}
            className="group p-5 bg-white rounded-2xl border border-slate-200 hover:border-emerald-400 shadow-xs hover:shadow-md transition-all text-left flex flex-col justify-between"
          >
            <div>
              <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-3 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                <Headphones className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-slate-900 group-hover:text-emerald-600 transition-colors text-sm sm:text-base">
                Contact Support
              </h3>
              <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                Reach out to our campus helpdesk or submit a demonstration assistance request.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center text-xs font-semibold text-emerald-600 group-hover:translate-x-1 transition-transform">
              <span>Get Direct Help</span>
              <ChevronRight className="w-4 h-4 ml-1" />
            </div>
          </button>
        </div>
      </section>

      {/* Simple Helpdesk Contact Banner */}
      <section className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-md border border-slate-800">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Need Direct Assistance?
            </h2>
            <p className="text-sm text-slate-300 max-w-xl leading-relaxed">
              If self-service troubleshooting does not solve your issue, our IT Helpdesk team is available to help.
            </p>
          </div>

          <div className="flex flex-wrap sm:flex-nowrap items-center gap-4">
            <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700 text-xs space-y-1">
              <div className="flex items-center gap-2 text-blue-300 font-semibold">
                <Phone className="w-3.5 h-3.5" />
                <span>{HELPDESK_PHONE}</span>
              </div>
              <div className="flex items-center gap-2 text-slate-400">
                <Clock className="w-3.5 h-3.5" />
                <span>{HELPDESK_HOURS}</span>
              </div>
              <div className="flex items-center gap-2 text-slate-400">
                <MapPin className="w-3.5 h-3.5" />
                <span>{HELPDESK_LOCATION}</span>
              </div>
            </div>

            <button
              onClick={() => onNavigate('contact')}
              className="px-5 py-3 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-xl transition-colors shadow-xs shrink-0"
            >
              Contact IT Support &rarr;
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
