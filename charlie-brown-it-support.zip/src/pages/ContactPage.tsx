import React, { useState } from 'react';
import {
  Phone,
  Mail,
  MapPin,
  Clock,
  Send,
  CheckCircle2,
  Info,
} from 'lucide-react';
import {
  ORG_NAME,
  HELPDESK_PHONE,
  HELPDESK_EMAIL,
  HELPDESK_HOURS,
  HELPDESK_LOCATION,
} from '../data/supportData';

interface SubmittedData {
  fullName: string;
  email: string;
  category: string;
  description: string;
  submittedAt: string;
}

export const ContactPage: React.FC = () => {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [category, setCategory] = useState('Hardware Support');
  const [description, setDescription] = useState('');

  const [submittedData, setSubmittedData] = useState<SubmittedData | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!fullName.trim() || !email.trim() || !description.trim()) {
      return;
    }

    const data: SubmittedData = {
      fullName: fullName.trim(),
      email: email.trim(),
      category,
      description: description.trim(),
      submittedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    // Save locally for demonstration
    try {
      const existing = localStorage.getItem('demo_support_requests');
      const list = existing ? JSON.parse(existing) : [];
      list.push(data);
      localStorage.setItem('demo_support_requests', JSON.stringify(list));
    } catch {
      // Ignore storage errors in private browsing
    }

    setSubmittedData(data);
  };

  const handleReset = () => {
    setFullName('');
    setEmail('');
    setCategory('Hardware Support');
    setDescription('');
    setSubmittedData(null);
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Page Header */}
      <div className="border-b border-slate-200 pb-5">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Contact IT Support
        </h1>
        <p className="text-sm sm:text-base text-slate-600 mt-1.5 max-w-3xl leading-relaxed">
          Submit a support request or contact the {ORG_NAME} helpdesk team.
        </p>
      </div>

      {/* Academic Project Demonstration Notice */}
      <div className="p-4 bg-blue-50 border border-blue-200 rounded-2xl flex items-start gap-3.5 text-xs sm:text-sm text-blue-900">
        <Info className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
        <p className="leading-relaxed">
          <strong>Demonstration Notice:</strong> This website was created for a university group project. Submitting this form stores your request locally on this device for demonstration purposes.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Support Request Form (Left Column) */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs">
          {submittedData ? (
            <div className="space-y-6 text-center py-4">
              <div className="w-14 h-14 bg-emerald-50 border border-emerald-200 text-emerald-600 rounded-2xl flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>

              <div className="space-y-1">
                <h2 className="text-xl font-bold text-slate-900">
                  Request Recorded (Demonstration)
                </h2>
                <p className="text-sm text-slate-600">
                  Thank you, {submittedData.fullName}! Your request has been recorded locally.
                </p>
              </div>

              {/* Submitted Details Box */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-left text-xs sm:text-sm space-y-2">
                <div>
                  <span className="text-slate-400 font-medium block">Contact:</span>
                  <span className="text-slate-900 font-semibold">{submittedData.fullName} ({submittedData.email})</span>
                </div>
                <div>
                  <span className="text-slate-400 font-medium block">Category:</span>
                  <span className="text-slate-900 font-semibold">{submittedData.category}</span>
                </div>
                <div>
                  <span className="text-slate-400 font-medium block">Problem Description:</span>
                  <p className="text-slate-700 mt-0.5 leading-relaxed bg-white p-2.5 rounded-lg border border-slate-100">
                    {submittedData.description}
                  </p>
                </div>
              </div>

              <button
                onClick={handleReset}
                className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold transition-colors shadow-xs"
              >
                Submit Another Request
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <h2 className="text-lg font-bold text-slate-900">
                  Request IT Assistance
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Please fill out the form below with basic details about the problem.
                </p>
              </div>

              {/* 1. Full Name */}
              <div className="space-y-1.5">
                <label
                  htmlFor="contact-name"
                  className="block text-xs font-bold text-slate-700 uppercase tracking-wider"
                >
                  Full Name <span className="text-rose-500">*</span>
                </label>
                <input
                  id="contact-name"
                  type="text"
                  required
                  placeholder="e.g. Charlie Brown"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
                />
              </div>

              {/* 2. Email Address */}
              <div className="space-y-1.5">
                <label
                  htmlFor="contact-email"
                  className="block text-xs font-bold text-slate-700 uppercase tracking-wider"
                >
                  Email Address <span className="text-rose-500">*</span>
                </label>
                <input
                  id="contact-email"
                  type="email"
                  required
                  placeholder="e.g. charlie@charliebrown-org.edu"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
                />
              </div>

              {/* 3. Issue Category */}
              <div className="space-y-1.5">
                <label
                  htmlFor="contact-category"
                  className="block text-xs font-bold text-slate-700 uppercase tracking-wider"
                >
                  Issue Category <span className="text-rose-500">*</span>
                </label>
                <select
                  id="contact-category"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
                >
                  <option value="Hardware Support">Hardware Support (PC, Monitor, Printer)</option>
                  <option value="Software Support">Software Support (Applications, Office)</option>
                  <option value="Network / Wi-Fi">Network / Wi-Fi Connectivity</option>
                  <option value="Account / Login">Account & Sign-in</option>
                  <option value="Other Question">Other Question</option>
                </select>
              </div>

              {/* 4. Short Description */}
              <div className="space-y-1.5">
                <label
                  htmlFor="contact-description"
                  className="block text-xs font-bold text-slate-700 uppercase tracking-wider"
                >
                  Short Description of the Problem <span className="text-rose-500">*</span>
                </label>
                <textarea
                  id="contact-description"
                  required
                  rows={4}
                  placeholder="Please describe what happened, any error messages, and what you were doing..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all resize-y"
                />
              </div>

              <button
                type="submit"
                className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold shadow-xs transition-colors"
              >
                <Send className="w-4 h-4" />
                <span>Submit Support Request</span>
              </button>
            </form>
          )}
        </div>

        {/* Direct Helpdesk Contacts (Right Column) */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
            <h2 className="text-base font-bold text-slate-900 border-b border-slate-100 pb-3">
              Helpdesk Information
            </h2>

            <div className="space-y-3.5 text-xs sm:text-sm text-slate-700">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center shrink-0 mt-0.5">
                  <Phone className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-semibold text-slate-900 block">Phone Support</span>
                  <span className="text-slate-600">{HELPDESK_PHONE}</span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0 mt-0.5">
                  <Mail className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-semibold text-slate-900 block">Email Inquiries</span>
                  <span className="text-slate-600">{HELPDESK_EMAIL}</span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center shrink-0 mt-0.5">
                  <Clock className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-semibold text-slate-900 block">Operating Hours</span>
                  <span className="text-slate-600">{HELPDESK_HOURS}</span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0 mt-0.5">
                  <MapPin className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-semibold text-slate-900 block">Walk-In Location</span>
                  <span className="text-slate-600">{HELPDESK_LOCATION}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Tip Box */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl text-xs text-slate-600 leading-relaxed">
            <span className="font-bold text-slate-900 block mb-1">
              Before submitting a request:
            </span>
            Try checking our <strong>Tutorials</strong> and <strong>FAQs</strong> pages. Many common problems, like Wi-Fi reconnections or slow computers, can be resolved in a couple of minutes!
          </div>
        </div>
      </div>
    </div>
  );
};
