import React, { useState, useEffect } from 'react';
import {
  HelpCircle,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { FAQS } from '../data/supportData';
import { NavPage } from '../types';

interface FaqsPageProps {
  initialTargetId?: string;
  onNavigate?: (page: NavPage) => void;
}

export const FaqsPage: React.FC<FaqsPageProps> = ({ initialTargetId }) => {
  // Accordion state: map of faq id to boolean (open/closed)
  const [openFaqIds, setOpenFaqIds] = useState<Record<string, boolean>>({
    'faq-1': true,
  });

  useEffect(() => {
    if (initialTargetId) {
      setOpenFaqIds((prev) => ({ ...prev, [initialTargetId]: true }));
      const el = document.getElementById(`faq-item-${initialTargetId}`);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      }
    }
  }, [initialTargetId]);

  const toggleFaq = (id: string) => {
    setOpenFaqIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Page Header */}
      <div className="border-b border-slate-200 pb-5">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Frequently Asked Questions
        </h1>
        <p className="text-sm sm:text-base text-slate-600 mt-1.5 max-w-3xl leading-relaxed">
          Quick answers to common IT support questions.
        </p>
      </div>

      {/* FAQ Accordion List - exactly 6 concise questions */}
      <div className="space-y-3">
        {FAQS.map((faq) => {
          const isOpen = !!openFaqIds[faq.id];
          return (
            <div
              key={faq.id}
              id={`faq-item-${faq.id}`}
              className={`bg-white rounded-xl border transition-all overflow-hidden ${
                isOpen
                  ? 'border-blue-400 shadow-xs'
                  : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              <button
                type="button"
                onClick={() => toggleFaq(faq.id)}
                aria-expanded={isOpen}
                className="w-full flex items-center justify-between p-4 sm:p-5 text-left transition-colors"
              >
                <div className="flex items-center gap-3 min-w-0 pr-4">
                  <div
                    className={`w-7 h-7 rounded-md flex items-center justify-center shrink-0 ${
                      isOpen
                        ? 'bg-blue-100 text-blue-700'
                        : 'bg-slate-100 text-slate-500'
                    }`}
                  >
                    <HelpCircle className="w-4 h-4" />
                  </div>
                  <h2 className="text-sm sm:text-base font-bold text-slate-900">
                    {faq.question}
                  </h2>
                </div>

                <div className="shrink-0 p-1 text-slate-400">
                  {isOpen ? (
                    <ChevronUp className="w-5 h-5 text-blue-600" />
                  ) : (
                    <ChevronDown className="w-5 h-5" />
                  )}
                </div>
              </button>

              {isOpen && (
                <div className="px-4 sm:px-5 pb-5 pt-1 text-sm text-slate-600 leading-relaxed border-t border-slate-100">
                  <p>{faq.answer}</p>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
