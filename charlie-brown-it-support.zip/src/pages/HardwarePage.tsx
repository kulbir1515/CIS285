import React, { useState, useEffect } from 'react';
import {
  Power,
  Monitor,
  Printer,
  Mouse,
  Usb,
  ArrowRight,
  LifeBuoy,
  CheckCircle,
  Lightbulb,
} from 'lucide-react';
import { HARDWARE_ISSUES } from '../data/supportData';
import { NavPage } from '../types';

interface HardwarePageProps {
  initialTargetId?: string;
  onNavigate: (page: NavPage) => void;
}

const ICON_MAP: Record<string, React.ElementType> = {
  Power: Power,
  Monitor: Monitor,
  Printer: Printer,
  Mouse: Mouse,
  Usb: Usb,
};

export const HardwarePage: React.FC<HardwarePageProps> = ({
  initialTargetId,
  onNavigate,
}) => {
  const [selectedIssueId, setSelectedIssueId] = useState<string>(
    initialTargetId || HARDWARE_ISSUES[0].id
  );

  useEffect(() => {
    if (initialTargetId) {
      setSelectedIssueId(initialTargetId);
      const el = document.getElementById(`hardware-detail-${initialTargetId}`);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      }
    }
  }, [initialTargetId]);

  const currentIssue =
    HARDWARE_ISSUES.find((i) => i.id === selectedIssueId) || HARDWARE_ISSUES[0];

  const IconComponent = ICON_MAP[currentIssue.icon] || Power;

  return (
    <div className="space-y-8 pb-12">
      {/* Page Header */}
      <div className="border-b border-slate-200 pb-5">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Hardware Support
        </h1>
        <p className="text-sm sm:text-base text-slate-600 mt-1.5 max-w-3xl leading-relaxed">
          Simple troubleshooting steps for common computer equipment, monitors, printers, and accessories.
        </p>
      </div>

      {/* Main Layout: Left Issue Selector + Right Detail Guide */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: 5 Common Hardware Problems */}
        <div className="lg:col-span-4 space-y-2">
          <p className="text-xs font-bold uppercase tracking-wider text-slate-400 px-1 mb-2">
            Common Hardware Issues
          </p>
          <div className="space-y-1.5">
            {HARDWARE_ISSUES.map((issue) => {
              const ItemIcon = ICON_MAP[issue.icon] || Power;
              const isSelected = issue.id === selectedIssueId;
              return (
                <button
                  key={issue.id}
                  id={`hw-btn-${issue.id}`}
                  onClick={() => setSelectedIssueId(issue.id)}
                  className={`w-full flex items-center justify-between p-3.5 rounded-xl text-left transition-all border ${
                    isSelected
                      ? 'bg-blue-600 text-white border-blue-600 shadow-xs font-semibold'
                      : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                        isSelected
                          ? 'bg-white/20 text-white'
                          : 'bg-blue-50 text-blue-600'
                      }`}
                    >
                      <ItemIcon className="w-4 h-4" />
                    </div>
                    <span className="text-xs sm:text-sm truncate">
                      {issue.title}
                    </span>
                  </div>
                  <ArrowRight
                    className={`w-4 h-4 shrink-0 transition-transform ${
                      isSelected ? 'text-white translate-x-0.5' : 'text-slate-300'
                    }`}
                  />
                </button>
              );
            })}
          </div>

          {/* Quick IT Helpdesk Card */}
          <div className="mt-6 p-4 bg-slate-50 rounded-2xl border border-slate-200 text-xs text-slate-600 space-y-2">
            <span className="font-bold text-slate-900 block text-xs uppercase tracking-wide">
              Equipment Assistance
            </span>
            <p className="leading-relaxed">
              If an accessory or power cable is faulty, our IT Helpdesk counter can provide tested replacement equipment.
            </p>
            <button
              onClick={() => onNavigate('contact')}
              className="text-blue-600 hover:text-blue-700 font-semibold flex items-center gap-1 pt-1"
            >
              <span>Contact Support Counter</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Right Column: Selected Issue Detail Card */}
        <div
          id={`hardware-detail-${currentIssue.id}`}
          className="lg:col-span-8 bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-6"
        >
          {/* Header */}
          <div className="flex items-center gap-4 border-b border-slate-100 pb-5">
            <div className="w-12 h-12 rounded-xl bg-blue-50 border border-blue-100 text-blue-600 flex items-center justify-center shrink-0">
              <IconComponent className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-blue-600">
                Hardware Guide
              </span>
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
                {currentIssue.title}
              </h2>
            </div>
          </div>

          {/* Description */}
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/80 text-xs sm:text-sm text-slate-700 leading-relaxed">
            <span className="font-semibold text-slate-900 block mb-1">
              Problem Description:
            </span>
            {currentIssue.symptoms.join('. ')}.
          </div>

          {/* 2-3 Simple Steps */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Simple Troubleshooting Steps
            </h3>
            <div className="space-y-3">
              {currentIssue.steps.map((step, idx) => (
                <div
                  key={idx}
                  className="flex items-start gap-3.5 p-4 rounded-xl border border-slate-200 bg-white"
                >
                  <span className="w-6 h-6 rounded-full bg-blue-600 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                    {idx + 1}
                  </span>
                  <div className="space-y-1 text-xs sm:text-sm">
                    <h4 className="font-bold text-slate-900">
                      {step.title}
                    </h4>
                    <p className="text-slate-600 leading-relaxed">
                      {step.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* ProTip */}
          {currentIssue.proTip && (
            <div className="flex items-start gap-3 p-3.5 bg-amber-50/70 border border-amber-200 rounded-xl text-xs text-amber-900">
              <Lightbulb className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <p className="leading-relaxed">
                <strong>Helpful Tip:</strong> {currentIssue.proTip}
              </p>
            </div>
          )}

          {/* Next Steps / Contact IT Support */}
          <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-slate-50 p-4 rounded-xl">
            <div className="flex items-center gap-2.5 text-xs text-slate-700">
              <LifeBuoy className="w-4 h-4 text-blue-600 shrink-0" />
              <span>
                <strong>Still not working?</strong> {currentIssue.escalation}
              </span>
            </div>
            <button
              onClick={() => onNavigate('contact')}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-xl transition-colors shrink-0 shadow-xs"
            >
              Contact IT Support &rarr;
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
