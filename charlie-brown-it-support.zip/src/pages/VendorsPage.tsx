import React from 'react';
import {
  ExternalLink,
  Laptop,
  Printer,
  Cloud,
  ShieldCheck,
} from 'lucide-react';
import { VENDORS } from '../data/supportData';
import { NavPage } from '../types';

interface VendorsPageProps {
  onNavigate?: (page: NavPage) => void;
}

export const VendorsPage: React.FC<VendorsPageProps> = () => {
  const getIcon = (id: string) => {
    switch (id) {
      case 'v-microsoft':
        return <Cloud className="w-6 h-6 text-sky-600" />;
      case 'v-apple':
        return <Laptop className="w-6 h-6 text-slate-800" />;
      case 'v-dell':
        return <Laptop className="w-6 h-6 text-blue-600" />;
      case 'v-hp':
        return <Printer className="w-6 h-6 text-cyan-600" />;
      case 'v-lenovo':
        return <Laptop className="w-6 h-6 text-red-600" />;
      default:
        return <Laptop className="w-6 h-6 text-slate-600" />;
    }
  };

  const getIconBg = (id: string) => {
    switch (id) {
      case 'v-microsoft':
        return 'bg-sky-50 border-sky-100';
      case 'v-apple':
        return 'bg-slate-100 border-slate-200';
      case 'v-dell':
        return 'bg-blue-50 border-blue-100';
      case 'v-hp':
        return 'bg-cyan-50 border-cyan-100';
      case 'v-lenovo':
        return 'bg-red-50 border-red-100';
      default:
        return 'bg-slate-50 border-slate-100';
    }
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Page Header */}
      <div className="border-b border-slate-200 pb-5">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Vendor Support
        </h1>
        <p className="text-sm sm:text-base text-slate-600 mt-1.5 max-w-3xl leading-relaxed">
          Direct links to official manufacturer support websites.
        </p>
      </div>

      {/* Grid of exactly 5 vendor cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {VENDORS.map((vendor) => (
          <div
            key={vendor.id}
            className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs hover:shadow-md hover:border-slate-300 transition-all flex flex-col justify-between"
          >
            <div className="space-y-4">
              <div className="flex items-center gap-3.5">
                <div
                  className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 border ${getIconBg(
                    vendor.id
                  )}`}
                >
                  {getIcon(vendor.id)}
                </div>
                <div>
                  <h2 className="text-lg font-bold text-slate-900 leading-snug">
                    {vendor.name}
                  </h2>
                </div>
              </div>

              <p className="text-sm text-slate-600 leading-relaxed min-h-[40px]">
                {vendor.notes}
              </p>
            </div>

            <div className="pt-5 mt-4 border-t border-slate-100">
              <a
                href={vendor.supportUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold shadow-xs transition-colors"
              >
                <span>Visit Official Support Website</span>
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </div>
        ))}
      </div>

      {/* Safety Notice */}
      <div className="p-4 sm:p-5 bg-slate-50 border border-slate-200 rounded-2xl flex items-start sm:items-center gap-3.5 text-xs sm:text-sm text-slate-700">
        <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5 sm:mt-0" />
        <p className="leading-relaxed">
          Always access manufacturer support through verified official websites. Never enter device credentials on unverified third-party pages.
        </p>
      </div>
    </div>
  );
};
