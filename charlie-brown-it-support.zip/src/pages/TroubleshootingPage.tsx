import React, { useState, useEffect } from 'react';
import {
  Gauge,
  WifiOff,
  Printer,
  AlertTriangle,
  Monitor,
  ChevronDown,
  ChevronUp,
  BookOpen,
  HelpCircle,
  Headphones,
  ArrowRight,
} from 'lucide-react';
import { TROUBLESHOOTING_TOPICS } from '../data/supportData';
import { NavPage } from '../types';

interface TroubleshootingPageProps {
  initialTargetId?: string;
  onNavigate: (page: NavPage) => void;
}

const ICON_MAP: Record<string, React.ElementType> = {
  Gauge: Gauge,
  WifiOff: WifiOff,
  Printer: Printer,
  AlertTriangle: AlertTriangle,
  HardDrive: Monitor,
};

export const TroubleshootingPage: React.FC<TroubleshootingPageProps> = ({
  initialTargetId,
  onNavigate,
}) => {
  // Allow expanding/collapsing issues for easy scanning
  const [openTopicId, setOpenTopicId] = useState<string>(
    initialTargetId || TROUBLESHOOTING_TOPICS[0].id
  );

  useEffect(() => {
    if (initialTargetId) {
      setOpenTopicId(initialTargetId);
      const el = document.getElementById(`troubleshoot-item-${initialTargetId}`);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      }
    }
  }, [initialTargetId]);

  return (
    <div className="space-y-8 pb-12">
      {/* Page Header */}
      <div className="border-b border-slate-200 pb-5">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Troubleshooting Guide
        </h1>
        <p className="text-sm sm:text-base text-slate-600 mt-1.5 max-w-3xl leading-relaxed">
          Quick, practical solutions for the 5 most common IT issues.
        </p>
      </div>

      {/* 5 Common Problem Cards */}
      <div className="space-y-4">
        {TROUBLESHOOTING_TOPICS.map((topic) => {
          const isOpen = openTopicId === topic.id;
          const IconComp = ICON_MAP[topic.icon] || AlertTriangle;

          return (
            <div
              key={topic.id}
              id={`troubleshoot-item-${topic.id}`}
              className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs transition-all"
            >
              {/* Accordion Header */}
              <button
                onClick={() => setOpenTopicId(isOpen ? '' : topic.id)}
                className="w-full p-5 sm:p-6 flex items-center justify-between gap-4 text-left hover:bg-slate-50/60 transition-colors"
                aria-expanded={isOpen}
              >
                <div className="flex items-center gap-3.5 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center shrink-0 border border-amber-100">
                    <IconComp className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-base sm:text-lg font-bold text-slate-900">
                      {topic.title}
                    </h2>
                    <p className="text-xs text-slate-500 mt-0.5 line-clamp-1">
                      Common causes: {topic.commonCauses.join(', ')}
                    </p>
                  </div>
                </div>

                <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500 shrink-0">
                  {isOpen ? (
                    <ChevronUp className="w-4 h-4" />
                  ) : (
                    <ChevronDown className="w-4 h-4" />
                  )}
                </div>
              </button>

              {/* Accordion Content */}
              {isOpen && (
                <div className="px-5 sm:px-6 pb-6 pt-2 border-t border-slate-100 space-y-4">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    Recommended Steps
                  </h3>

                  <div className="space-y-3">
                    {topic.primarySteps.map((step) => (
                      <div
                        key={step.step}
                        className="flex items-start gap-3 p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 text-xs sm:text-sm"
                      >
                        <span className="w-5 h-5 rounded-full bg-amber-600 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                          {step.step}
                        </span>
                        <div>
                          <strong className="text-slate-900 block mb-0.5">
                            {step.title}
                          </strong>
                          <p className="text-slate-600 leading-relaxed">
                            {step.details}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Helpful Navigation Links to Tutorials, FAQs, and Contact */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
        {/* Tutorials link */}
        <button
          onClick={() => onNavigate('tutorials')}
          className="p-5 bg-white rounded-2xl border border-slate-200 hover:border-purple-300 shadow-xs hover:shadow-md transition-all text-left flex items-start justify-between group"
        >
          <div className="space-y-1.5">
            <div className="w-8 h-8 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center mb-2">
              <BookOpen className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-slate-900 group-hover:text-purple-600 transition-colors">
              Our Tutorials
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Step-by-step guides created by our team for error screenshots and Wi-Fi.
            </p>
          </div>
          <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-purple-600 group-hover:translate-x-1 transition-all mt-1" />
        </button>

        {/* FAQs link */}
        <button
          onClick={() => onNavigate('faqs')}
          className="p-5 bg-white rounded-2xl border border-slate-200 hover:border-teal-300 shadow-xs hover:shadow-md transition-all text-left flex items-start justify-between group"
        >
          <div className="space-y-1.5">
            <div className="w-8 h-8 rounded-lg bg-teal-50 text-teal-600 flex items-center justify-center mb-2">
              <HelpCircle className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-slate-900 group-hover:text-teal-600 transition-colors">
              Frequently Asked Questions
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Quick answers to the 6 most common IT questions.
            </p>
          </div>
          <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-teal-600 group-hover:translate-x-1 transition-all mt-1" />
        </button>

        {/* Contact Support link */}
        <button
          onClick={() => onNavigate('contact')}
          className="p-5 bg-white rounded-2xl border border-slate-200 hover:border-blue-300 shadow-xs hover:shadow-md transition-all text-left flex items-start justify-between group"
        >
          <div className="space-y-1.5">
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center mb-2">
              <Headphones className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
              Contact IT Support
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              If the problem continues, reach out to our team for assistance.
            </p>
          </div>
          <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-blue-600 group-hover:translate-x-1 transition-all mt-1" />
        </button>
      </div>
    </div>
  );
};
