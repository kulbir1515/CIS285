import React, { useState, useEffect, useId } from 'react';
import {
  Search,
  BookOpen,
  Camera,
  Activity,
  Printer,
  Wifi,
  Clock,
  GraduationCap,
  ChevronRight,
  ArrowRight,
  CheckCircle2,
  AlertTriangle,
  HelpCircle,
  X,
  FileText,
  ShieldAlert,
  ExternalLink,
  RotateCcw,
  Sparkles,
  Info,
  Check,
  ImageIcon,
  Monitor,
} from 'lucide-react';
import { ORIGINAL_TUTORIALS } from '../data/originalTutorials';
import { OriginalTutorial, NavPage } from '../types';
import { ORG_NAME } from '../data/supportData';

const EXTERNAL_LEARNING_RESOURCES = [
  {
    title: 'Microsoft Windows Support',
    url: 'https://support.microsoft.com/windows',
    description: 'Official troubleshooting guides and help articles for Windows operating systems.',
    icon: Monitor,
  },
  {
    title: 'GCFGlobal Computer Basics',
    url: 'https://edu.gcfglobal.org/en/computerbasics/',
    description: 'Free, beginner-friendly lessons covering essential computer concepts and everyday skills.',
    icon: BookOpen,
  },
] as const;

interface TutorialsPageProps {
  initialTargetId?: string;
  onNavigate: (page: NavPage) => void;
}

const CATEGORIES = [
  'All Tutorials',
  'Windows Basics',
  'Troubleshooting',
  'Hardware Support',
  'Network Support',
] as const;

type CategoryFilter = (typeof CATEGORIES)[number];

const ICON_MAP: Record<string, React.ElementType> = {
  Camera: Camera,
  Activity: Activity,
  Printer: Printer,
  Wifi: Wifi,
};

export const TutorialsPage: React.FC<TutorialsPageProps> = ({
  initialTargetId,
  onNavigate,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<CategoryFilter>('All Tutorials');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeTutorial, setActiveTutorial] = useState<OriginalTutorial | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);
  const searchInputId = useId();

  // Handle deep-linking from search or external button
  useEffect(() => {
    if (initialTargetId) {
      const match = ORIGINAL_TUTORIALS.find((t) => t.id === initialTargetId);
      if (match) {
        setActiveTutorial(match);
      }
    }
  }, [initialTargetId]);

  // Handle ESC key to close active modal
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && activeTutorial) {
        setActiveTutorial(null);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeTutorial]);

  // Lock body scroll when modal is open
  useEffect(() => {
    if (activeTutorial) {
      const originalStyle = window.getComputedStyle(document.body).overflow;
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = originalStyle;
      };
    }
  }, [activeTutorial]);

  // Filter tutorials based on category and search query
  const filteredTutorials = ORIGINAL_TUTORIALS.filter((item) => {
    const matchesCategory =
      selectedCategory === 'All Tutorials' || item.category === selectedCategory;

    const query = searchQuery.toLowerCase().trim();
    const matchesQuery =
      !query ||
      item.title.toLowerCase().includes(query) ||
      item.summary.toLowerCase().includes(query) ||
      item.introduction.toLowerCase().includes(query) ||
      item.category.toLowerCase().includes(query);

    return matchesCategory && matchesQuery;
  });

  const handleCopyLink = (tutorialId: string) => {
    if (navigator?.clipboard) {
      navigator.clipboard.writeText(window.location.href.split('#')[0]);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  return (
    <div className="space-y-8 pb-12">
      {/* 1. Page Heading and Introduction */}
      <div className="border-b border-slate-200 pb-5">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-purple-600 mb-1">
          <BookOpen className="w-3.5 h-3.5" />
          <span>TEAM-CREATED GUIDES</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Our Tutorials
        </h1>
        <p className="text-sm sm:text-base text-slate-600 mt-1.5 max-w-3xl leading-relaxed">
          Step-by-step guides created by our team to help you solve common IT problems.
        </p>
        <p className="text-xs text-slate-400 mt-2 flex items-center gap-1.5">
          <Info className="w-3.5 h-3.5 text-purple-600 shrink-0" />
          <span>Tutorials created by the Charlie Brown IT Support team for students, faculty, and staff.</span>
        </p>
      </div>

      {/* 2. Search and Category Filters */}
      <div className="flex flex-col lg:flex-row gap-3.5 items-stretch lg:items-center justify-between">
        {/* Category Pill Filters */}
        <div className="flex flex-wrap gap-2">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                selectedCategory === cat
                  ? 'bg-purple-600 text-white shadow-xs font-semibold'
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Search Input */}
        <div className="relative w-full lg:w-80">
          <label htmlFor={searchInputId} className="sr-only">
            Search our original tutorials
          </label>
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            id={searchInputId}
            type="text"
            placeholder="Search tutorials by title or topic..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm bg-white border border-slate-200 rounded-lg focus:outline-hidden focus:border-purple-500 focus:ring-1 focus:ring-purple-500 text-slate-900 placeholder:text-slate-400"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5"
              title="Clear search"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* 3. Original Tutorial Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredTutorials.map((tut) => {
          const IconComp = ICON_MAP[tut.iconName] || BookOpen;

          return (
            <article
              key={tut.id}
              className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs hover:border-purple-300 hover:shadow-md transition-all flex flex-col justify-between space-y-5"
            >
              <div className="space-y-4">
                {/* Header row: Category & Meta */}
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-purple-700 bg-purple-50 px-2.5 py-0.5 rounded-md border border-purple-100">
                    {tut.category}
                  </span>
                  <div className="flex items-center gap-3 text-xs text-slate-500">
                    <span className="inline-flex items-center gap-1">
                      <GraduationCap className="w-3.5 h-3.5 text-purple-600" />
                      {tut.difficulty}
                    </span>
                    <span>•</span>
                    <span className="inline-flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      {tut.estimatedTime}
                    </span>
                  </div>
                </div>

                {/* Title and Icon */}
                <div className="flex items-start gap-3.5">
                  <div className="w-11 h-11 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center shrink-0 border border-purple-100">
                    <IconComp className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-lg sm:text-xl font-bold text-slate-900 leading-snug">
                      {tut.title}
                    </h2>
                  </div>
                </div>

                {/* Short Description */}
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  {tut.summary}
                </p>

                {/* Key learning bullets preview */}
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-1.5 text-xs text-slate-600">
                  <span className="font-semibold text-slate-800 text-[11px] uppercase tracking-wider block">
                    Key Steps Covered:
                  </span>
                  <ul className="space-y-1 text-slate-600">
                    {tut.steps.slice(0, 2).map((s) => (
                      <li key={s.stepNumber} className="flex items-start gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-purple-600 shrink-0 mt-0.5" />
                        <span>{s.title}</span>
                      </li>
                    ))}
                    <li className="text-[11px] text-slate-400 pl-5">
                      + {tut.steps.length - 2} more detailed steps with screenshot placeholders
                    </li>
                  </ul>
                </div>
              </div>

              {/* Card Footer: Read Tutorial Button */}
              <div className="pt-4 border-t border-slate-100 flex items-center justify-between gap-3">
                <span className="text-[11px] text-slate-400">
                  By {ORG_NAME} IT Team
                </span>
                <button
                  type="button"
                  onClick={() => setActiveTutorial(tut)}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs sm:text-sm font-semibold shadow-xs transition-colors group cursor-pointer"
                >
                  <span>Read Tutorial</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                </button>
              </div>
            </article>
          );
        })}
      </div>

      {/* Empty State */}
      {filteredTutorials.length === 0 && (
        <div className="text-center py-12 bg-white rounded-2xl border border-slate-200 p-8 space-y-3">
          <HelpCircle className="w-10 h-10 text-purple-400 mx-auto" />
          <h3 className="text-base font-bold text-slate-900">
            No original tutorials found
          </h3>
          <p className="text-slate-500 text-xs sm:text-sm max-w-md mx-auto">
            No tutorials match your current search query "{searchQuery}" in category "{selectedCategory}".
          </p>
          <button
            type="button"
            onClick={() => {
              setSelectedCategory('All Tutorials');
              setSearchQuery('');
            }}
            className="mt-2 inline-flex items-center gap-1.5 px-4 py-2 bg-purple-50 hover:bg-purple-100 text-purple-700 rounded-lg text-xs font-semibold transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset filters & search</span>
          </button>
        </div>
      )}

      {/* Additional Learning Resources Section */}
      <section className="pt-6 border-t border-slate-200 space-y-5">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-purple-600 mb-1">
            <ExternalLink className="w-3.5 h-3.5" />
            <span>ADDITIONAL LEARNING RESOURCES</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
            Additional Learning Resources
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-2xl leading-relaxed">
            Helpful external tutorials and official guides from trusted educational providers.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {EXTERNAL_LEARNING_RESOURCES.map((resource) => {
            const IconComp = resource.icon;
            return (
              <div
                key={resource.title}
                className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs hover:border-purple-300 hover:shadow-md transition-all flex flex-col justify-between space-y-5"
              >
                <div className="space-y-4">
                  <div className="w-11 h-11 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center shrink-0 border border-purple-100">
                    <IconComp className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-slate-900">
                      {resource.title}
                    </h3>
                    <p className="text-xs sm:text-sm text-slate-600 mt-1.5 leading-relaxed">
                      {resource.description}
                    </p>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100">
                  <a
                    href={resource.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs sm:text-sm font-semibold transition-colors shadow-xs"
                  >
                    <span>Visit Tutorial</span>
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Support Team Banner */}
      <div className="p-6 bg-slate-900 text-slate-200 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border border-slate-800">
        <div className="space-y-1 text-xs sm:text-sm">
          <h2 className="font-bold text-white text-base">
            Need guidance not covered in these tutorials?
          </h2>
          <p className="text-slate-400 max-w-xl leading-relaxed">
            Our helpdesk staff at {ORG_NAME} is available to walk you through any unique hardware or software scenario, or create an additional customized tutorial.
          </p>
        </div>

        <button
          type="button"
          onClick={() => onNavigate('contact')}
          className="px-5 py-2.5 bg-purple-600 hover:bg-purple-500 text-white text-xs sm:text-sm font-semibold rounded-xl transition-colors shrink-0 shadow-xs cursor-pointer"
        >
          Contact Support &rarr;
        </button>
      </div>

      {/* 4. Dedicated Tutorial Detail View Modal */}
      {activeTutorial && (
        <div
          className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200"
          onClick={() => setActiveTutorial(null)}
          role="dialog"
          aria-modal="true"
          aria-labelledby="tutorial-modal-title"
        >
          <div
            className="bg-white rounded-2xl sm:rounded-3xl shadow-2xl max-w-4xl w-full max-h-[90vh] flex flex-col overflow-hidden border border-slate-200 my-auto text-left"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="p-5 sm:p-6 border-b border-slate-200 bg-slate-50/80 flex items-start justify-between gap-4 sticky top-0 z-10 backdrop-blur-sm">
              <div className="space-y-1.5">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-purple-700 bg-purple-50 px-2.5 py-0.5 rounded-md border border-purple-200">
                    {activeTutorial.category}
                  </span>
                  <span className="text-xs text-slate-500 font-medium">
                    Difficulty: <strong className="text-slate-700">{activeTutorial.difficulty}</strong>
                  </span>
                  <span className="text-xs text-slate-400">•</span>
                  <span className="text-xs text-slate-500 font-medium">
                    {activeTutorial.estimatedTime}
                  </span>
                </div>
                <h2
                  id="tutorial-modal-title"
                  className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight leading-snug"
                >
                  {activeTutorial.title}
                </h2>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => handleCopyLink(activeTutorial.id)}
                  className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-200 rounded-lg transition-colors text-xs flex items-center gap-1"
                  title="Share Tutorial"
                >
                  {copiedLink ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-600" />
                      <span className="text-emerald-700 font-medium hidden sm:inline">Copied</span>
                    </>
                  ) : (
                    <>
                      <FileText className="w-4 h-4" />
                      <span className="hidden sm:inline">Share</span>
                    </>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTutorial(null)}
                  className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
                  aria-label="Close tutorial modal"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Modal Body Content (Scrollable) */}
            <div className="p-5 sm:p-8 overflow-y-auto space-y-8 text-slate-800 text-sm">
              {/* Introduction & Attribution */}
              <div className="space-y-3">
                <div className="p-4 bg-purple-50/60 border border-purple-100 rounded-xl text-purple-950 text-xs sm:text-sm leading-relaxed">
                  <strong className="font-semibold text-purple-900 block mb-1">
                    About this tutorial:
                  </strong>
                  {activeTutorial.introduction}
                </div>
                <p className="text-[11px] text-slate-400 italic">
                  Authored by the Charlie Brown IT Support team for CIS 285 End User Training and Support.
                </p>
              </div>

              {/* Two Column Grid: What You Will Learn & Requirements */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* What You Will Learn */}
                <div className="p-5 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                  <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-purple-700">
                    <CheckCircle2 className="w-4 h-4 text-purple-600" />
                    <span>What You Will Learn</span>
                  </div>
                  <ul className="space-y-2 text-xs text-slate-700">
                    {activeTutorial.whatYouWillLearn.map((item, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-purple-600 mt-1.5 shrink-0" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Requirements Before Starting */}
                <div className="p-5 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                  <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-700">
                    <Info className="w-4 h-4 text-slate-600" />
                    <span>Requirements Before Starting</span>
                  </div>
                  <ul className="space-y-2 text-xs text-slate-700">
                    {activeTutorial.requirements.map((req, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-slate-500 mt-1.5 shrink-0" />
                        <span>{req}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Numbered Step-by-Step Instructions */}
              <div className="space-y-6">
                <div className="border-b border-slate-200 pb-2">
                  <h3 className="text-lg font-bold text-slate-900 tracking-tight">
                    Step-by-Step Instructions
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Follow each numbered step in sequence.
                  </p>
                </div>

                <div className="space-y-6">
                  {activeTutorial.steps.map((st) => (
                    <div
                      key={st.stepNumber}
                      className="p-5 bg-white rounded-2xl border border-slate-200 shadow-2xs space-y-4"
                    >
                      {/* Step Header */}
                      <div className="flex items-start gap-3">
                        <span className="w-7 h-7 rounded-lg bg-purple-600 text-white font-bold text-xs flex items-center justify-center shrink-0">
                          {st.stepNumber}
                        </span>
                        <div className="space-y-1">
                          <h4 className="font-bold text-slate-900 text-base">
                            {st.title}
                          </h4>
                          <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
                            {st.instruction}
                          </p>
                        </div>
                      </div>

                      {/* Detail points */}
                      {st.details && st.details.length > 0 && (
                        <ul className="ml-10 space-y-1.5 text-xs text-slate-600 list-disc list-outside pl-2">
                          {st.details.map((d, dIdx) => (
                            <li key={dIdx}>{d}</li>
                          ))}
                        </ul>
                      )}

                      {/* Clearly Marked Screenshot Placeholder */}
                      <div className="ml-2 sm:ml-10 p-4 sm:p-5 rounded-xl border-2 border-dashed border-purple-200 bg-purple-50/40 space-y-2">
                        <div className="flex items-center gap-2 text-xs font-bold text-purple-900">
                          <ImageIcon className="w-4 h-4 text-purple-600" />
                          <span>{st.screenshotPlaceholder.label}</span>
                        </div>
                        <p className="text-xs text-slate-600 leading-relaxed">
                          {st.screenshotPlaceholder.description}
                        </p>
                        <div className="pt-1.5 border-t border-purple-200/60 flex items-center justify-between text-[11px] text-purple-700">
                          <span>Status: Screenshot placeholder</span>
                          <span className="italic">To be captured and added by Charlie Brown IT team</span>
                        </div>
                      </div>

                      {/* Pro Tip or Caution */}
                      {st.proTip && (
                        <div className="ml-2 sm:ml-10 p-3 bg-blue-50 border border-blue-200/80 rounded-xl text-xs text-blue-900 flex items-start gap-2">
                          <Sparkles className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                          <div>
                            <strong className="font-semibold text-blue-950">Tip: </strong>
                            <span>{st.proTip}</span>
                          </div>
                        </div>
                      )}

                      {st.caution && (
                        <div className="ml-2 sm:ml-10 p-3 bg-amber-50 border border-amber-200/80 rounded-xl text-xs text-amber-900 flex items-start gap-2">
                          <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                          <div>
                            <strong className="font-semibold text-amber-950">Caution: </strong>
                            <span>{st.caution}</span>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Expected Result Section */}
              <div className="p-5 bg-emerald-50/80 border border-emerald-200 rounded-2xl space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-800">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Expected Result</span>
                </div>
                <p className="text-xs sm:text-sm text-emerald-950 leading-relaxed">
                  {activeTutorial.expectedResult}
                </p>
              </div>

              {/* Common Problems & Troubleshooting Tips */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-800">
                  <HelpCircle className="w-4 h-4 text-purple-600" />
                  <span>Common Problems & Troubleshooting Tips</span>
                </div>
                <div className="space-y-2.5">
                  {activeTutorial.commonProblems.map((cp, idx) => (
                    <div
                      key={idx}
                      className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-1.5"
                    >
                      <p className="font-bold text-slate-900">
                        Problem: <span className="font-semibold text-rose-700">{cp.problem}</span>
                      </p>
                      <p className="text-slate-600 leading-relaxed">
                        <strong className="font-semibold text-slate-800">Solution: </strong>
                        {cp.solution}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Safety Reminders */}
              {activeTutorial.safetyReminders && activeTutorial.safetyReminders.length > 0 && (
                <div className="p-5 bg-amber-50/70 border border-amber-200 rounded-2xl space-y-2.5 text-xs text-amber-950">
                  <div className="flex items-center gap-2 font-bold uppercase tracking-wider text-amber-800">
                    <ShieldAlert className="w-4 h-4 text-amber-600" />
                    <span>Safety & Security Reminders</span>
                  </div>
                  <ul className="space-y-1.5 list-disc list-inside">
                    {activeTutorial.safetyReminders.map((sr, idx) => (
                      <li key={idx} className="leading-relaxed">
                        {sr}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Technical References for Instructions Verification */}
              {activeTutorial.references && activeTutorial.references.length > 0 && (
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-2 text-slate-500">
                  <span className="font-bold text-slate-700 block">
                    Technical Verification References
                  </span>
                  <p className="text-[11px] leading-relaxed text-slate-500">
                    The instructions in this tutorial were authored by the Charlie Brown IT Support team and cross-referenced with official vendor technical documentation:
                  </p>
                  <ul className="space-y-1">
                    {activeTutorial.references.map((ref, idx) => (
                      <li key={idx} className="text-[11px] flex items-center gap-1.5 flex-wrap">
                        <strong className="text-slate-700">{ref.title}</strong>
                        <span>— {ref.source}</span>
                        {ref.url && (
                          <a
                            href={ref.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-purple-600 hover:underline inline-flex items-center gap-0.5 ml-1"
                          >
                            <span>Verify source</span>
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        )}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            {/* Modal Footer Controls */}
            <div className="p-4 sm:p-5 border-t border-slate-200 bg-slate-50 flex items-center justify-between gap-3">
              <span className="text-xs text-slate-500 hidden sm:inline">
                Press <kbd className="px-1.5 py-0.5 bg-white border border-slate-300 rounded text-[10px] font-mono">ESC</kbd> to close
              </span>
              <div className="flex items-center gap-2.5 ml-auto">
                <button
                  type="button"
                  onClick={() => setActiveTutorial(null)}
                  className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                >
                  Back to All Tutorials
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setActiveTutorial(null);
                    onNavigate('contact');
                  }}
                  className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                >
                  Still Need Help? Open Ticket &rarr;
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
