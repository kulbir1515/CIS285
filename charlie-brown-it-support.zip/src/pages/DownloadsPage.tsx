import React from 'react';
import {
  ExternalLink,
  Globe,
  Archive,
  Terminal,
  Sliders,
  ShieldCheck,
  Compass,
} from 'lucide-react';
import { DOWNLOADS } from '../data/supportData';
import { NavPage } from '../types';

interface DownloadsPageProps {
  onNavigate?: (page: NavPage) => void;
}

export const DownloadsPage: React.FC<DownloadsPageProps> = () => {
  // Map specific icons for each tool
  const getIcon = (id: string) => {
    switch (id) {
      case 'dl-chrome':
        return <Globe className="w-6 h-6 text-blue-600" />;
      case 'dl-firefox':
        return <Compass className="w-6 h-6 text-amber-600" />;
      case 'dl-7zip':
        return <Archive className="w-6 h-6 text-emerald-600" />;
      case 'dl-powertoys':
        return <Sliders className="w-6 h-6 text-indigo-600" />;
      case 'dl-powershell':
        return <Terminal className="w-6 h-6 text-blue-700" />;
      default:
        return <Globe className="w-6 h-6 text-slate-600" />;
    }
  };

  const getIconBg = (id: string) => {
    switch (id) {
      case 'dl-chrome':
        return 'bg-blue-50 border-blue-100';
      case 'dl-firefox':
        return 'bg-amber-50 border-amber-100';
      case 'dl-7zip':
        return 'bg-emerald-50 border-emerald-100';
      case 'dl-powertoys':
        return 'bg-indigo-50 border-indigo-100';
      case 'dl-powershell':
        return 'bg-blue-50 border-blue-100';
      default:
        return 'bg-slate-50 border-slate-100';
    }
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Page Header */}
      <div className="border-b border-slate-200 pb-5">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Software Downloads
        </h1>
        <p className="text-sm sm:text-base text-slate-600 mt-1.5 max-w-3xl leading-relaxed">
          Useful tools to help with everyday computing tasks.
        </p>
      </div>

      {/* Grid of exactly 5 download cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {DOWNLOADS.map((item) => (
          <div
            key={item.id}
            className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs hover:shadow-md hover:border-slate-300 transition-all flex flex-col justify-between"
          >
            <div className="space-y-4">
              <div className="flex items-center gap-3.5">
                <div
                  className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 border ${getIconBg(
                    item.id
                  )}`}
                >
                  {getIcon(item.id)}
                </div>
                <div>
                  <h2 className="text-lg font-bold text-slate-900">
                    {item.name}
                  </h2>
                </div>
              </div>

              <p className="text-sm text-slate-600 leading-relaxed min-h-[40px]">
                {item.description}
              </p>
            </div>

            <div className="pt-5 mt-4 border-t border-slate-100">
              <a
                href={item.officialUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold shadow-xs transition-colors"
              >
                <span>Visit Official Download Page</span>
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </div>
        ))}
      </div>

      {/* Safety Note */}
      <div className="p-4 sm:p-5 bg-slate-50 border border-slate-200 rounded-2xl flex items-start sm:items-center gap-3.5 text-xs sm:text-sm text-slate-700">
        <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5 sm:mt-0" />
        <p className="leading-relaxed">
          Download software only from trusted official sources. Follow your organization's software installation policies.
        </p>
      </div>
    </div>
  );
};
