import React, { useState, useEffect } from 'react';
import {
  AppWindow,
  Mail,
  Lock,
  Download,
  HardDrive,
  ArrowRight,
  BookOpen,
  LifeBuoy,
  Lightbulb,
} from 'lucide-react';
import { SOFTWARE_ISSUES } from '../data/supportData';
import { NavPage } from '../types';

interface SoftwarePageProps {
  initialTargetId?: string;
  onNavigate: (page: NavPage) => void;
}

const ICON_MAP: Record<string, React.ElementType> = {
  AppWindow: AppWindow,
  Mail: Mail,
  Lock: Lock,
  Download: Download,
  HardDrive: HardDrive,
};

export const SoftwarePage: React.FC<SoftwarePageProps> = ({
  initialTargetId,
  onNavigate,
}) => {
  const [selectedSoftwareId, setSelectedSoftwareId] = useState<string>(
    initialTargetId || SOFTWARE_ISSUES[0].id
  );

  useEffect(() => {
    if (initialTargetId) {
      setSelectedSoftwareId(initialTargetId);
      const el = document.getElementById(`software-detail-${initialTargetId}`);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      }
    }
  }, [initialTargetId]);

  const currentSoftware =
    SOFTWARE_ISSUES.find((s) => s.id === selectedSoftwareId) || SOFTWARE_ISSUES[0];

  const IconComponent = ICON_MAP[currentSoftware.icon] || AppWindow;

  return (
    <div className="space-y-8 pb-12">
      {/* Page Header */}
      <div className="border-b border-slate-200 pb-5">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Software Support
        </h1>
        <p className="text-sm sm:text-base text-slate-600 mt-1.5 max-w-3xl leading-relaxed">
          Practical troubleshooting steps for applications, email, accounts, and file saving.
        </p>
      </div>

      {/* Top Issue Tabs (5 items) */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
        {SOFTWARE_ISSUES.map((sw) => {
          const ItemIcon = ICON_MAP[sw.icon] || AppWindow;
          const isSelected = sw.id === selectedSoftwareId;
          return (
            <button
              key={sw.id}
              id={`sw-tab-${sw.id}`}
              onClick={() => setSelectedSoftwareId(sw.id)}
              className={`p-3.5 rounded-xl text-center border transition-all flex flex-col items-center justify-center gap-2 ${
                isSelected
                  ? 'bg-blue-600 text-white border-blue-600 shadow-xs font-semibold'
                  : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200 hover:border-slate-300'
              }`}
            >
              <div
                className={`w-9 h-9 rounded-lg flex items-center justify-center ${
                  isSelected ? 'bg-white/20 text-white' : 'bg-indigo-50 text-indigo-600'
                }`}
              >
                <ItemIcon className="w-5 h-5" />
              </div>
              <span className="text-xs font-medium line-clamp-1">{sw.title}</span>
            </button>
          );
        })}
      </div>

      {/* Main Issue Detail Card */}
      <div
        id={`software-detail-${currentSoftware.id}`}
        className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-6"
      >
        {/* Header */}
        <div className="flex items-center gap-4 border-b border-slate-100 pb-5">
          <div className="w-12 h-12 rounded-xl bg-indigo-50 border border-indigo-100 text-indigo-600 flex items-center justify-center shrink-0">
            <IconComponent className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">
              {currentSoftware.app} Issue
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
              {currentSoftware.title}
            </h2>
          </div>
        </div>

        {/* Short Explanation */}
        <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/80 text-xs sm:text-sm text-slate-700 leading-relaxed">
          <span className="font-semibold text-slate-900 block mb-1">
            Common Signs:
          </span>
          {currentSoftware.symptoms.join('. ')}.
        </div>

        {/* 2-3 Practical Steps */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Practical Resolution Steps
          </h3>
          <div className="space-y-3">
            {currentSoftware.steps.map((step, idx) => (
              <div
                key={idx}
                className="flex items-start gap-3.5 p-4 rounded-xl border border-slate-200 bg-white"
              >
                <span className="w-6 h-6 rounded-full bg-indigo-600 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                  {idx + 1}
                </span>
                <div className="space-y-1 text-xs sm:text-sm">
                  <h4 className="font-bold text-slate-900">
                    {step.title}
                  </h4>
                  <p className="text-slate-600 leading-relaxed">
                    {step.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Helpful Tip */}
        {currentSoftware.proTip && (
          <div className="flex items-start gap-3 p-3.5 bg-amber-50/70 border border-amber-200 rounded-xl text-xs text-amber-900">
            <Lightbulb className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              <strong>Helpful Tip:</strong> {currentSoftware.proTip}
            </p>
          </div>
        )}

        {/* Direct Link to Tutorials Page */}
        <div className="p-4 bg-purple-50 border border-purple-200 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs sm:text-sm text-purple-900">
          <div className="flex items-center gap-3">
            <BookOpen className="w-5 h-5 text-purple-600 shrink-0" />
            <p className="leading-relaxed">
              Need a detailed step-by-step walkthrough? Visit our team-created <strong>Tutorials</strong> page.
            </p>
          </div>
          <button
            onClick={() => onNavigate('tutorials')}
            className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold rounded-xl transition-colors shrink-0 shadow-xs"
          >
            Open Tutorials &rarr;
          </button>
        </div>

        {/* Contact IT Support */}
        <div className="pt-2 border-t border-slate-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 text-xs text-slate-600">
            <LifeBuoy className="w-4 h-4 text-slate-400 shrink-0" />
            <span>
              {currentSoftware.alternativeSolution || 'If the problem persists, our IT team can assist you.'}
            </span>
          </div>
          <button
            onClick={() => onNavigate('contact')}
            className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1"
          >
            <span>Contact IT Support</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
