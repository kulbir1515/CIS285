/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { NavPage } from './types';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { GlobalSearchModal } from './components/GlobalSearchModal';
import { HomePage } from './pages/HomePage';
import { HardwarePage } from './pages/HardwarePage';
import { SoftwarePage } from './pages/SoftwarePage';
import { TroubleshootingPage } from './pages/TroubleshootingPage';
import { FaqsPage } from './pages/FaqsPage';
import { TutorialsPage } from './pages/TutorialsPage';
import { DownloadsPage } from './pages/DownloadsPage';
import { VendorsPage } from './pages/VendorsPage';
import { ContactPage } from './pages/ContactPage';
import {
  ChevronRight,
  Home,
} from 'lucide-react';

export default function App() {
  const [currentPage, setCurrentPage] = useState<NavPage>('home');
  const [targetId, setTargetId] = useState<string | undefined>(undefined);
  const [searchModalOpen, setSearchModalOpen] = useState(false);

  // Handle navigation
  const handleNavigate = (page: NavPage, newTargetId?: string) => {
    setCurrentPage(page);
    setTargetId(newTargetId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const pageTitles: Record<NavPage, string> = {
    home: 'Home',
    hardware: 'Hardware Support',
    software: 'Software Support',
    troubleshooting: 'Troubleshooting',
    faqs: 'FAQs',
    tutorials: 'Tutorials',
    downloads: 'Downloads',
    vendors: 'Vendor Support',
    contact: 'Contact / Support',
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-100/60 font-sans text-slate-900 antialiased selection:bg-blue-600 selection:text-white">
      {/* Global Header */}
      <Header
        currentPage={currentPage}
        onNavigate={handleNavigate}
        onOpenSearch={() => setSearchModalOpen(true)}
      />

      {/* Breadcrumb Navigation Bar (Sub-header) */}
      {currentPage !== 'home' && (
        <div className="bg-white border-b border-slate-200 py-2.5 px-4 sm:px-6 text-xs text-slate-500">
          <div className="max-w-7xl mx-auto flex items-center gap-1.5 flex-wrap">
            <button
              onClick={() => handleNavigate('home')}
              className="flex items-center gap-1 hover:text-blue-600 transition-colors"
            >
              <Home className="w-3.5 h-3.5" />
              <span>Home</span>
            </button>
            <ChevronRight className="w-3 h-3 text-slate-400" />
            <span className="font-semibold text-slate-800">
              {pageTitles[currentPage]}
            </span>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 pt-6 sm:pt-8">
        {currentPage === 'home' && (
          <HomePage
            onNavigate={handleNavigate}
            onOpenSearch={() => setSearchModalOpen(true)}
          />
        )}
        {currentPage === 'hardware' && (
          <HardwarePage
            initialTargetId={targetId}
            onNavigate={handleNavigate}
          />
        )}
        {currentPage === 'software' && (
          <SoftwarePage
            initialTargetId={targetId}
            onNavigate={handleNavigate}
          />
        )}
        {currentPage === 'troubleshooting' && (
          <TroubleshootingPage
            initialTargetId={targetId}
            onNavigate={handleNavigate}
          />
        )}
        {currentPage === 'faqs' && (
          <FaqsPage
            initialTargetId={targetId}
            onNavigate={handleNavigate}
          />
        )}
        {currentPage === 'tutorials' && (
          <TutorialsPage
            initialTargetId={targetId}
            onNavigate={handleNavigate}
          />
        )}
        {currentPage === 'downloads' && (
          <DownloadsPage onNavigate={handleNavigate} />
        )}
        {currentPage === 'vendors' && (
          <VendorsPage onNavigate={handleNavigate} />
        )}
        {currentPage === 'contact' && <ContactPage />}
      </main>

      {/* Global Search Modal (Ctrl+K or trigger) */}
      <GlobalSearchModal
        isOpen={searchModalOpen}
        onClose={() => setSearchModalOpen(false)}
        onSelectResult={(page, itemTargetId) => {
          handleNavigate(page, itemTargetId);
        }}
      />

      {/* Consistent Footer */}
      <Footer onNavigate={handleNavigate} />
    </div>
  );
}
