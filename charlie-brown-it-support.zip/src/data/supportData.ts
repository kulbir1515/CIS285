import {
  HardwareIssue,
  SoftwareIssue,
  TroubleshootingTopic,
  FAQItem,
  TutorialItem,
  ResourceItem,
  DownloadItem,
  VendorItem,
  SupportTicket,
  DiagnosticNode,
} from '../types';

export const ORG_NAME = 'The Charlie Brown Organization';
export const APP_TITLE = 'Charlie Brown IT Support';
export const HELPDESK_PHONE = '(555) 242-7543';
export const HELPDESK_EMAIL = 'support@charliebrown-org.edu';
export const HELPDESK_HOURS = 'Monday – Friday: 7:30 AM – 6:00 PM (PST)';
export const HELPDESK_LOCATION = 'Charlie Brown Hall, Suite 204 (Campus IT Center)';

export const POPULAR_PROBLEMS = [
  {
    id: 'wont-turn-on',
    title: "Computer won't turn on",
    category: 'Hardware',
    badge: 'Urgent',
    desc: 'Power button does nothing or lights flash briefly and turn off.',
    targetPage: 'hardware' as const,
    targetId: 'hw-power',
  },
  {
    id: 'slow-computer',
    title: 'Slow computer',
    category: 'Troubleshooting',
    badge: 'Common',
    desc: 'Applications lag, programs freeze, or computer takes minutes to boot.',
    targetPage: 'troubleshooting' as const,
    targetId: 'tb-slow',
  },
  {
    id: 'wifi-broken',
    title: 'Wi-Fi not working',
    category: 'Hardware & Network',
    badge: 'Common',
    desc: 'Cannot connect to internet or "No Internet, Secured" message appears.',
    targetPage: 'hardware' as const,
    targetId: 'hw-wifi',
  },
  {
    id: 'printer-error',
    title: 'Printer not working',
    category: 'Hardware',
    badge: 'Office',
    desc: 'Printer shows offline, paper jam, or print jobs remain stuck in queue.',
    targetPage: 'hardware' as const,
    targetId: 'hw-printer',
  },
  {
    id: 'forgot-password',
    title: 'Forgotten password',
    category: 'Tutorials',
    badge: 'Account',
    desc: 'Locked out of your Charlie Brown Org account or password expired.',
    targetPage: 'tutorials' as const,
    targetId: 'tut-password',
  },
  {
    id: 'software-not-opening',
    title: 'Software not opening',
    category: 'Software',
    badge: 'Apps',
    desc: 'Office 365, Word, Excel, or web browsers crash immediately on launch.',
    targetPage: 'software' as const,
    targetId: 'sw-word',
  },
  {
    id: 'low-storage',
    title: 'Computer running out of storage',
    category: 'Troubleshooting',
    badge: 'Maintenance',
    desc: '"Low disk space" warnings and inability to save new documents or files.',
    targetPage: 'troubleshooting' as const,
    targetId: 'tb-disk',
  },
  {
    id: 'virus-malware',
    title: 'Virus/malware concerns',
    category: 'Software & Security',
    badge: 'Security',
    desc: 'Suspicious pop-ups, browser redirects, or unexpected warning messages.',
    targetPage: 'software' as const,
    targetId: 'sw-antivirus',
  },
];

export const HARDWARE_ISSUES: HardwareIssue[] = [
  {
    id: 'hw-power',
    title: 'Computer Will Not Turn On',
    icon: 'Power',
    symptoms: [
      'No lights or fan noise when pressing the power button',
      'Power light briefly blinks orange or turns off',
    ],
    quickCheck: 'Verify that the surge protector and wall outlet have power.',
    steps: [
      {
        title: 'Check Power Cables',
        description: 'Ensure the power cord is firmly plugged into both the wall outlet and the computer.',
      },
      {
        title: 'Test the Outlet',
        description: 'Plug another device (such as a lamp or phone charger) into the outlet to verify it works.',
      },
      {
        title: 'Perform a Power Drain',
        description: 'Unplug the power cord, hold the power button down for 20 seconds, reconnect power, and turn it on.',
      },
    ],
    proTip: 'If using a laptop, check if the battery charging indicator light turns on.',
    escalation: 'If the computer still will not turn on, contact IT Support.',
  },
  {
    id: 'hw-monitor',
    title: 'Monitor Has No Display',
    icon: 'Monitor',
    symptoms: [
      'Computer turns on, but the screen remains black',
      'Monitor displays a "No Signal" message',
    ],
    quickCheck: 'Confirm that the monitor power indicator light is turned on.',
    steps: [
      {
        title: 'Check Monitor Power',
        description: 'Press the power button on the monitor to make sure it is powered on.',
      },
      {
        title: 'Secure the Video Cable',
        description: 'Disconnect and firmly reconnect the HDMI, DisplayPort, or USB-C cable on both ends.',
      },
      {
        title: 'Check the Input Source',
        description: 'Press the Source or Input button on the monitor and select the correct port.',
      },
    ],
    proTip: 'Try a different video cable or port if one is available.',
    escalation: 'If the screen remains black, contact IT Support.',
  },
  {
    id: 'hw-printer',
    title: 'Printer Is Not Working',
    icon: 'Printer',
    symptoms: [
      'Print jobs do not print or get stuck in queue',
      'Printer status appears as offline',
    ],
    quickCheck: 'Verify the printer has paper loaded and no error lights are blinking.',
    steps: [
      {
        title: 'Check Power and Paper',
        description: 'Ensure the printer is powered on, has paper, and shows no error messages or paper jams.',
      },
      {
        title: 'Restart the Printer',
        description: 'Turn off the printer, wait 15 seconds, and turn it back on to clear its memory.',
      },
      {
        title: 'Clear the Print Queue',
        description: 'Open printer settings on your computer, view the print queue, and cancel any stuck print jobs.',
      },
    ],
    proTip: 'Check our Tutorials page for a guide on clearing stuck print jobs.',
    escalation: 'If the printer still fails to print, contact IT Support.',
  },
  {
    id: 'hw-peripherals',
    title: 'Keyboard or Mouse Is Not Responding',
    icon: 'Mouse',
    symptoms: [
      'Mouse cursor is frozen or jumping',
      'Keystrokes do not appear on the screen',
    ],
    quickCheck: 'Check if the Caps Lock light or mouse sensor light illuminates.',
    steps: [
      {
        title: 'Reconnect the USB Cable',
        description: 'Unplug the keyboard or mouse and plug it into a different USB port directly on your computer.',
      },
      {
        title: 'Check Batteries and Power Switch',
        description: 'For wireless devices, replace the batteries and confirm the power switch is set to ON.',
      },
      {
        title: 'Restart Your Computer',
        description: 'Restart your computer to allow the operating system to reload peripheral drivers.',
      },
    ],
    proTip: 'Avoid connecting input devices through unpowered USB hubs when troubleshooting.',
    escalation: 'If the keyboard or mouse still does not respond, contact IT Support.',
  },
  {
    id: 'hw-connection',
    title: 'Basic Connection Problems',
    icon: 'Usb',
    symptoms: [
      'External drive, webcam, or dock is not recognized',
      '"USB device not recognized" notification appears',
    ],
    quickCheck: 'Try connecting the device to a different USB port.',
    steps: [
      {
        title: 'Unplug and Reconnect',
        description: 'Disconnect the device, wait 5 seconds, and plug it firmly into another port.',
      },
      {
        title: 'Connect Directly',
        description: 'Plug the device directly into the computer rather than an unpowered multi-port adapter.',
      },
      {
        title: 'Restart the Computer',
        description: 'Rebooting refreshes the operating system USB controllers and detects hardware changes.',
      },
    ],
    proTip: 'Always safely eject USB storage before unplugging to prevent data loss.',
    escalation: 'If connection problems persist, contact IT Support.',
  },
];

export const SOFTWARE_ISSUES: SoftwareIssue[] = [
  {
    id: 'sw-app-open',
    app: 'Applications',
    title: 'Application Will Not Open',
    icon: 'AppWindow',
    symptoms: [
      'Program freezes or closes immediately after opening',
      'App displays a "(Not Responding)" message',
    ],
    steps: [
      {
        title: 'Close Stuck Background Tasks',
        description: 'Open Task Manager (Ctrl + Shift + Esc) and end any frozen tasks for the application.',
      },
      {
        title: 'Restart Your Computer',
        description: 'Restarting clears temporary memory conflicts preventing programs from opening.',
      },
      {
        title: 'Check for Updates',
        description: 'Ensure both your operating system and the application have all available updates installed.',
      },
    ],
    proTip: 'See our Tutorials page for how to check system resource usage.',
    alternativeSolution: 'If the application still fails to open, contact IT Support.',
  },
  {
    id: 'sw-email',
    app: 'Email',
    title: 'Email Is Not Working',
    icon: 'Mail',
    symptoms: [
      'New emails are not syncing or sending',
      'Error message appears when opening your inbox',
    ],
    steps: [
      {
        title: 'Check Internet Connection',
        description: 'Confirm that other websites open in your browser to verify your internet connection is active.',
      },
      {
        title: 'Test Webmail Access',
        description: 'Sign into webmail using a web browser to verify your email account is active.',
      },
      {
        title: 'Restart the Email Client',
        description: 'Close and reopen your email application to force a fresh mailbox synchronization.',
      },
    ],
    proTip: 'If webmail works, the issue is with the desktop app rather than your email account.',
    alternativeSolution: 'If email remains unavailable, contact IT Support.',
  },
  {
    id: 'sw-signin',
    app: 'Login',
    title: 'Cannot Sign In',
    icon: 'Lock',
    symptoms: [
      'Password not accepted error message',
      'Account locked or sign-in blocked notice',
    ],
    steps: [
      {
        title: 'Check Keyboard Settings',
        description: 'Ensure Caps Lock is off and your keyboard language is set correctly.',
      },
      {
        title: 'Re-enter Your Password Carefully',
        description: 'Type your username and password slowly to avoid accidental typos.',
      },
      {
        title: 'Use Account Recovery',
        description: 'Follow your organization approved password recovery portal to reset your password.',
      },
    ],
    proTip: 'Never share your login credentials or security codes with anyone.',
    alternativeSolution: 'If your account remains locked, contact IT Support.',
  },
  {
    id: 'sw-install',
    app: 'Software',
    title: 'Software Installation Problem',
    icon: 'Download',
    symptoms: [
      'Installation fails or stops with an error message',
      'Administrator permission required prompt appears',
    ],
    steps: [
      {
        title: 'Check Organization Policies',
        description: 'Confirm that the software is approved for use on organization computers.',
      },
      {
        title: 'Run as Administrator',
        description: 'Right-click the installation setup file and choose "Run as administrator" if permitted.',
      },
      {
        title: 'Restart and Retry',
        description: 'Restart your computer to finish any pending updates, then run the installer again.',
      },
    ],
    proTip: 'Visit our Downloads page for verified software tools.',
    alternativeSolution: 'Contact IT Support to request software installation permissions.',
  },
  {
    id: 'sw-saving',
    app: 'Files',
    title: 'Files Are Not Saving Correctly',
    icon: 'HardDrive',
    symptoms: [
      '"File in use" or "Permission denied" error when saving',
      'Cloud drive sync error or yellow warning icon',
    ],
    steps: [
      {
        title: 'Use "Save As" with a New Name',
        description: 'Save a copy to your local Documents folder with a slightly different file name.',
      },
      {
        title: 'Check Storage Space',
        description: 'Confirm your computer drive or cloud account has sufficient free storage space.',
      },
      {
        title: 'Close Other Open Copies',
        description: 'Ensure the file is not currently open in another window or on another device.',
      },
    ],
    proTip: 'Save copies of important documents regularly to avoid lost work.',
    alternativeSolution: 'Contact IT Support if file errors persist.',
  },
];

export const TROUBLESHOOTING_TOPICS: TroubleshootingTopic[] = [
  {
    id: 'tb-slow',
    title: 'Slow Computer',
    urgency: 'Medium',
    icon: 'Gauge',
    commonCauses: [
      'Too many applications running simultaneously',
      'Computer has not been restarted recently',
    ],
    primarySteps: [
      {
        step: 1,
        title: 'Restart Your Computer',
        details: 'Save your work and restart the computer to clear temporary memory and background tasks.',
      },
      {
        step: 2,
        title: 'Close Unused Applications',
        details: 'Close heavy applications and unnecessary browser tabs to free up system memory.',
      },
      {
        step: 3,
        title: 'Check Task Manager',
        details: 'Press Ctrl + Shift + Esc to see which applications are consuming high CPU or memory.',
      },
    ],
  },
  {
    id: 'tb-wifi',
    title: 'Wi-Fi Connection Problem',
    urgency: 'High',
    icon: 'WifiOff',
    commonCauses: [
      'Wi-Fi turned off accidentally',
      'Incorrect wireless network selected',
    ],
    primarySteps: [
      {
        step: 1,
        title: 'Verify Wi-Fi Is Enabled',
        details: 'Check the Wi-Fi icon in your system tray and make sure Wi-Fi is ON and Airplane mode is OFF.',
      },
      {
        step: 2,
        title: 'Reconnect to the Network',
        details: 'Disconnect from the network and reconnect to the official organization network.',
      },
      {
        step: 3,
        title: 'Restart Your Computer',
        details: 'Restart your computer to reset your wireless network adapter.',
      },
    ],
  },
  {
    id: 'tb-printer',
    title: 'Printer Problem',
    urgency: 'Medium',
    icon: 'Printer',
    commonCauses: [
      'Printer offline or disconnected',
      'Stuck print job blocking the queue',
    ],
    primarySteps: [
      {
        step: 1,
        title: 'Check Power and Paper',
        details: 'Ensure the printer is turned on, loaded with paper, and shows no error lights.',
      },
      {
        step: 2,
        title: 'Clear Stuck Print Jobs',
        details: 'Open printer settings on your computer, view the print queue, and cancel stuck jobs.',
      },
      {
        step: 3,
        title: 'Restart the Printer',
        details: 'Turn off the printer, wait 15 seconds, and turn it back on to test printing.',
      },
    ],
  },
  {
    id: 'tb-login',
    title: 'Login Problem',
    urgency: 'High',
    icon: 'AlertTriangle',
    commonCauses: [
      'Caps Lock is turned on',
      'Incorrect username or password entered',
    ],
    primarySteps: [
      {
        step: 1,
        title: 'Check Caps Lock Key',
        details: 'Verify that Caps Lock is not accidentally turned on.',
      },
      {
        step: 2,
        title: 'Re-enter Login Details Carefully',
        details: 'Type your full username and password slowly to prevent spelling mistakes.',
      },
      {
        step: 3,
        title: 'Use Account Recovery',
        details: 'Follow your organization approved password recovery process or contact IT Support.',
      },
    ],
  },
  {
    id: 'tb-blackscreen',
    title: 'Black Screen',
    urgency: 'High',
    icon: 'HardDrive',
    commonCauses: [
      'Monitor turned off or cable loose',
      'Graphics driver temporarily unresponsive',
    ],
    primarySteps: [
      {
        step: 1,
        title: 'Check Monitor Power & Cable',
        details: 'Confirm the monitor is powered on and the video cable is firmly connected on both ends.',
      },
      {
        step: 2,
        title: 'Wake Graphics Driver',
        details: 'On Windows, press Windows Key + Ctrl + Shift + B to restart the display driver.',
      },
      {
        step: 3,
        title: 'Perform a Hard Reboot',
        details: 'Hold the computer power button for 15 seconds until it powers down, then restart it.',
      },
    ],
  },
];

export const DIAGNOSTIC_TREE: Record<string, DiagnosticNode> = {
  start: {
    id: 'start',
    question: 'What type of issue are you experiencing today?',
    options: [
      { label: 'Computer Power / Hardware issue', nextNodeId: 'node_hw' },
      { label: 'Internet or Network connection', nextNodeId: 'node_net' },
      { label: 'Software crash or application problem', nextNodeId: 'node_sw' },
      { label: 'Account / Login / Password problem', nextNodeId: 'node_acc' },
    ],
  },
  node_hw: {
    id: 'node_hw',
    question: 'Does the computer turn on at all?',
    options: [
      {
        label: 'No, completely black, no lights, no fans',
        solution: {
          title: 'Power Failure & Static Drain Procedure',
          description: 'Your machine is not receiving electricity or is locked in a static protection state.',
          steps: [
            'Verify wall outlet with a desk lamp or phone charger.',
            'Unplug power cable, hold power button down firmly for 30 seconds (static flush), then reconnect.',
            'If on a laptop, inspect the power brick LED light.',
          ],
          escalateNote: 'If still dead, bring device to Charlie Brown Hall Suite 204 for a free power supply diagnosis.',
        },
      },
      {
        label: 'Yes, lights come on but screen stays black',
        nextNodeId: 'node_display',
      },
      {
        label: 'Yes, but it makes loud beeping noises or shuts off after 5 seconds',
        solution: {
          title: 'Hardware POST Diagnostic Beep Code',
          description: 'Rhythmic beeps mean the motherboard has failed its Power-On Self-Test (usually RAM or GPU).',
          steps: [
            'Count the exact pattern (e.g., 3 short beeps, 1 long beep).',
            'Do not open the case if under organization warranty.',
            'Submit a ticket with the beep pattern so IT can bring matching RAM sticks.',
          ],
          escalateNote: 'Immediate hardware replacement available at the IT Helpdesk.',
        },
      },
    ],
  },
  node_display: {
    id: 'node_display',
    question: 'Are you using a desktop with an external monitor or a laptop?',
    options: [
      {
        label: 'Desktop with external monitor',
        solution: {
          title: 'Monitor Input & Video Cable Check',
          description: 'The computer is running, but the monitor is not displaying the video stream.',
          steps: [
            'Press the monitor power button and check if "No Signal" appears.',
            'Ensure video cable is plugged into the bottom horizontal graphics card, not top motherboard.',
            'Press Windows + Ctrl + Shift + B to wake the graphics driver.',
          ],
        },
      },
      {
        label: 'Laptop built-in display',
        solution: {
          title: 'Laptop Screen Brightness & External Display Test',
          description: 'The backlight may be turned down or the display resolution is hung.',
          steps: [
            'Press the brightness up key (usually F3 or F12).',
            'Plug into an external monitor or TV via HDMI to test if Windows loads.',
            'Press Windows Key + P to verify display is not set to "Second screen only".',
          ],
          escalateNote: 'If external monitor works but laptop screen remains dark, the internal display ribbon cable needs service.',
        },
      },
    ],
  },
  node_net: {
    id: 'node_net',
    question: 'Are other devices (like your phone) able to connect to Wi-Fi?',
    options: [
      {
        label: 'Yes, phone works, only my computer fails',
        solution: {
          title: 'Computer Network Stack Reconnect',
          description: 'Your computer network adapter cache or stored Wi-Fi credentials are stale.',
          steps: [
            'Right-click "CharlieBrown-Secure" network and click "Forget".',
            'Reconnect and re-enter your Charlie Brown Org email and password.',
            'Open Command Prompt and run "ipconfig /flushdns".',
          ],
        },
      },
      {
        label: 'No, all devices in this room fail to connect',
        solution: {
          title: 'Access Point or Building Outage',
          description: 'The wireless access point for your area may be experiencing a localized disruption.',
          steps: [
            'Check the IT Status Board on the Home page for active campus maintenance.',
            'Switch temporarily to the "CharlieBrown-Guest" network if available.',
            'Report the room number to IT Helpdesk at (555) 242-7543.',
          ],
          escalateNote: 'Helpdesk network technicians will dispatch a remote reset to the ceiling access point.',
        },
      },
    ],
  },
  node_sw: {
    id: 'node_sw',
    question: 'Which software is giving you trouble?',
    options: [
      {
        label: 'Microsoft 365 (Word, Excel, PowerPoint)',
        solution: {
          title: 'Office Quick Repair & Safe Mode',
          description: 'Microsoft 365 can be fixed without losing any user files.',
          steps: [
            'Hold CTRL while opening the app to launch in Safe Mode.',
            'Disable third-party add-ins under File > Options > Add-ins.',
            'Go to Windows Settings > Apps > Installed apps > Microsoft 365 > Modify > Quick Repair.',
          ],
        },
      },
      {
        label: 'Web Browser (Chrome, Edge, Firefox)',
        solution: {
          title: 'Browser Clean Reset & Cache Flush',
          description: 'Old session cookies frequently break authenticated campus web apps.',
          steps: [
            'Press Ctrl + Shift + Delete and clear cache and cookies from "All time".',
            'Open an Incognito / InPrivate window to test without extensions.',
            'Disable unapproved ad-blockers or extensions.',
          ],
        },
      },
      {
        label: 'Whole computer freezing or Blue Screen error',
        solution: {
          title: 'System Diagnostic & Resource Check',
          description: 'Operating system instability or memory leakage detected.',
          steps: [
            'Open Task Manager (Ctrl + Shift + Esc) and check CPU and Memory percentages.',
            'Ensure at least 15GB free on C: drive.',
            'Run "sfc /scannow" in Command Prompt (Administrator).',
          ],
        },
      },
    ],
  },
  node_acc: {
    id: 'node_acc',
    question: 'What account problem are you facing?',
    options: [
      {
        label: 'I forgot my password or it expired',
        solution: {
          title: 'Self-Service Password Reset Portal',
          description: 'You can reset your Charlie Brown Org password in under 2 minutes.',
          steps: [
            'Visit the official portal at password.charliebrown-org.edu.',
            'Enter your username and verify your secondary phone or authenticator code.',
            'Select a new passphrase with at least 12 characters, including numbers and symbols.',
          ],
        },
      },
      {
        label: 'Multi-Factor Authentication (MFA) push not coming through',
        solution: {
          title: 'MFA Code or Offline Verification',
          description: 'The Microsoft Authenticator notification may be delayed by cellular coverage.',
          steps: [
            'Click "I can\'t use my Microsoft Authenticator app right now" on the sign-in screen.',
            'Choose "Use a verification code" and read the 6-digit rolling code inside the app.',
            'Ensure phone is not in "Do Not Disturb" mode blocking push notifications.',
          ],
          escalateNote: 'If you lost or replaced your smartphone, call (555) 242-7543 to verify identity and reset your MFA device.',
        },
      },
    ],
  },
};

export const FAQS: FAQItem[] = [
  {
    id: 'faq-1',
    question: 'What should I do if my computer is running slowly?',
    answer: 'Save your work, restart your computer, and close applications you do not need. If the problem continues, contact IT Support.',
    category: 'General',
    tags: ['performance', 'slow', 'restart'],
  },
  {
    id: 'faq-2',
    question: 'What should I do if I cannot connect to Wi-Fi?',
    answer: 'Check that Wi-Fi is enabled and that you are connecting to the correct network. If the connection still fails, contact IT Support.',
    category: 'Network & Wi-Fi',
    tags: ['wifi', 'network', 'connection'],
  },
  {
    id: 'faq-3',
    question: 'What should I do if my printer is not working?',
    answer: "Check the printer's power, paper, connection, and print queue. If it still does not print, contact IT Support.",
    category: 'Hardware',
    tags: ['printer', 'hardware', 'queue'],
  },
  {
    id: 'faq-4',
    question: 'What should I do if I cannot sign in?',
    answer: "Check your username and keyboard settings. If you still cannot sign in, follow your organization's approved account recovery process.",
    category: 'Accounts & Access',
    tags: ['login', 'account', 'signin'],
  },
  {
    id: 'faq-5',
    question: 'How do I request IT support?',
    answer: 'Describe the problem, include any error message, and explain the steps you have already tried. Submit your request through the organization’s approved support channel.',
    category: 'General',
    tags: ['support', 'helpdesk', 'ticket'],
  },
  {
    id: 'faq-6',
    question: 'Is it safe to download software from any website?',
    answer: "No. Download software only from trusted official sources and follow your organization's installation policies.",
    category: 'Security',
    tags: ['security', 'download', 'safe'],
  },
];

export const TUTORIALS: TutorialItem[] = [
  {
    id: 'tut-gcflearnfree',
    title: 'GCFGlobal Learning Tutorials (Computer & Office Basics)',
    provider: 'GCFGlobal (Goodwill Community Foundation)',
    url: 'https://edu.gcfglobal.org',
    category: 'Computer & Office Basics',
    summary: 'Free, beginner-friendly online tutorials covering computer basics, Windows, macOS, typing, internet safety, and Microsoft Office.',
    description: 'GCFGlobal has provided world-class, free educational tutorials for over two decades. Their self-paced guides feature illustrated walkthroughs and videos covering everyday technical competencies from mouse and keyboard fundamentals to advanced Microsoft Excel formulas and cloud storage.',
    applicationsCovered: ['Computer Basics', 'Windows 10 & 11', 'Microsoft Word', 'Microsoft Excel', 'Microsoft PowerPoint', 'Internet Safety'],
    skillLevel: 'Beginner',
    accessType: '100% Free • No Sign-up Required',
    badge: 'Top Recommended for Beginners',
    featured: true,
  },
  {
    id: 'tut-mslearn',
    title: 'Microsoft Learn & Training Hub',
    provider: 'Microsoft Corporation',
    url: 'https://learn.microsoft.com/training/',
    category: 'Microsoft 365 & Windows',
    summary: 'Official interactive training modules, learning paths, and video labs directly from Microsoft.',
    description: 'The authoritative destination for mastering the Microsoft ecosystem. Access guided learning modules for Microsoft 365, Word, Excel, Teams, Outlook, OneDrive, SharePoint, and Windows administration with step-by-step interactive browser sandboxes and practice assessments.',
    applicationsCovered: ['Microsoft 365', 'Excel Formulas & PivotTables', 'Teams Meetings & Channels', 'Word Formatting', 'Outlook Email & Calendar', 'Windows 11'],
    skillLevel: 'All Levels',
    accessType: 'Free Official Microsoft Documentation & Labs',
    badge: 'Official Vendor Training',
    featured: true,
  },
  {
    id: 'tut-adobe',
    title: 'Adobe Creative Cloud Tutorials & Help Center',
    provider: 'Adobe Systems',
    url: 'https://helpx.adobe.com/support.html',
    category: 'Creative & Media Software',
    summary: 'Official Adobe video walkthroughs, sample project files, and step-by-step guides for creative tools.',
    description: 'Whether editing documents in Acrobat Pro, retouching photos in Photoshop, creating vector logos in Illustrator, or editing video in Premiere Pro, Adobe’s official Help & Tutorials portal provides hands-on sample files and bite-sized video lessons for creators of all skill levels.',
    applicationsCovered: ['Adobe Acrobat Pro', 'Adobe Photoshop', 'Adobe Illustrator', 'Adobe Premiere Pro', 'Adobe InDesign', 'Creative Cloud Sync'],
    skillLevel: 'Beginner',
    accessType: 'Free Video Walkthroughs & Guided Projects',
    badge: 'Official Adobe Hub',
    featured: true,
  },
  {
    id: 'tut-google',
    title: 'Google Workspace Learning Center',
    provider: 'Google',
    url: 'https://support.google.com/a/users',
    category: 'Cloud Collaboration',
    summary: 'Official Google user training guides, cheat sheets, and productivity switch guides for Workspace apps.',
    description: 'Master cloud-first productivity with Google’s official Workspace user guides. Features quick-reference cheat sheets, side-by-side transition guides for users moving from Microsoft Office to Google Docs/Sheets, and collaborative sharing walkthroughs.',
    applicationsCovered: ['Google Docs', 'Google Sheets', 'Google Drive', 'Google Slides', 'Google Meet', 'Gmail & Google Calendar'],
    skillLevel: 'All Levels',
    accessType: 'Free Official Google Knowledgebase & Guides',
    badge: 'Official Google Portal',
    featured: true,
  },
  {
    id: 'tut-apple',
    title: 'Apple Mac Support & macOS User Guide',
    provider: 'Apple Inc.',
    url: 'https://support.apple.com/guide/mac-help/welcome/mac',
    category: 'macOS & Operating Systems',
    summary: 'Official illustrated manual and walkthroughs for navigating and troubleshooting macOS on MacBooks and iMacs.',
    description: 'A comprehensive guide for Mac users covering window management, Finder organization, Time Machine automated backups, Trackpad gestures, Apple Mail setup, and macOS privacy/security permissions.',
    applicationsCovered: ['macOS Navigation', 'Finder & File Management', 'Time Machine Backups', 'Spotlight Search', 'System Settings & Security'],
    skillLevel: 'Beginner',
    accessType: 'Free Official Apple Guides',
    badge: 'Apple Official',
  },
  {
    id: 'tut-zoom',
    title: 'Zoom Video Communications Learning Center',
    provider: 'Zoom',
    url: 'https://learning.zoom.us/',
    category: 'Video Conferencing & Remote Work',
    summary: 'Official on-demand video courses and live training for hosting flawless meetings and webinars.',
    description: 'Master virtual communication with Zoom’s dedicated Learning Center. Includes concise modules on microphone and camera troubleshooting, screen sharing with audio, setting up breakout rooms, and configuring security passcodes.',
    applicationsCovered: ['Zoom Meetings', 'Screen Sharing & Annotations', 'Audio & Webcam Setup', 'Virtual Backgrounds', 'Breakout Rooms & Security'],
    skillLevel: 'Beginner',
    accessType: 'Free On-Demand Video Courses',
    badge: 'Zoom Official',
  },
  {
    id: 'tut-canva',
    title: 'Canva Design School',
    provider: 'Canva',
    url: 'https://www.canva.com/designschool/tutorials/',
    category: 'Presentation & Graphic Design',
    summary: 'Short, practical design courses and visual tutorials for creating presentations, flyers, and infographics.',
    description: 'Designed specifically for non-designers, Canva Design School offers quick, engaging lessons on presentation layout, typography, color harmony, and formatting documents for print and web distribution.',
    applicationsCovered: ['Presentation Slides', 'Infographics & Posters', 'Document Styling', 'Social Media Graphics', 'Brand Kits'],
    skillLevel: 'Beginner',
    accessType: '100% Free Interactive Lessons',
    badge: 'Interactive & Visual',
  },
  {
    id: 'tut-w3schools',
    title: 'W3Schools Web & Coding Tutorials',
    provider: 'W3Schools',
    url: 'https://www.w3schools.com',
    category: 'Web Technology & Development',
    summary: 'The web’s most popular hands-on reference for learning HTML, CSS, JavaScript, SQL, and Python basics.',
    description: 'Features the famous interactive "Try it Yourself" code editor. Perfect for students and staff looking to understand web pages, format intranet content, query databases with SQL, or automate basic tasks with Python.',
    applicationsCovered: ['HTML & CSS', 'JavaScript Basics', 'Python Programming', 'SQL Queries', 'Git Version Control'],
    skillLevel: 'Beginner',
    accessType: '100% Free Interactive Tutorials',
    badge: 'Hands-On Code Sandbox',
  },
];

export const RESOURCES: ResourceItem[] = [
  {
    id: 'res-cis285',
    title: 'CIS 285 End User Training and Support Project Overview',
    category: 'CIS 285 Project',
    description: 'Academic documentation, end-user training objectives, helpdesk service architecture, and support workflows for this technical support portal at the University of the Fraser Valley.',
    content: 'This technical support web portal was designed and implemented as part of the CIS 285 "End User Training and Support" curriculum at the University of the Fraser Valley (UFV). The primary mission is providing accessible, empowering, and beginner-friendly self-service technical support to end users across The Charlie Brown Organization. By combining structured troubleshooting walkthroughs, vetted external learning hubs, essential diagnostic utility downloads, and an integrated ticket dispatch management system, this portal directly tackles repetitive helpdesk inquiries and enhances digital autonomy.',
    extraList: [
      'Course & Institution: CIS 285 End User Training and Support • University of the Fraser Valley (UFV)',
      'Client Organization: The Charlie Brown Organization',
      'Target Stakeholders: Staff, Faculty, Students, and Tier-1/Tier-2 Helpdesk Technicians',
      'Functional Modules: Hardware Diagnostics, Software Troubleshooting, Knowledgebase FAQs, External Learning Hubs, Vetted Utility Downloads, Vendor Directory, and Support Ticket Management',
      'Pedagogical Focus: End-user empowerment, accessible self-service troubleshooting, technical literacy training, and transparent escalation pathways',
    ],
  },
  {
    id: 'res-policy',
    title: 'Charlie Brown Organization Acceptable Use Policy (AUP)',
    category: 'Organization Policies',
    description: 'Summary of regulations, user responsibilities, privacy guidelines, and network etiquette.',
    content: 'All computing hardware, mobile devices, networking infrastructure, and software licenses provided by The Charlie Brown Organization are dedicated to furthering academic and operational goals. Users are responsible for exercising ethical judgment, protecting password credentials, and maintaining equipment in good working order.',
    extraList: [
      'Account Security: Sharing passwords or MFA tokens with colleagues, friends, or family is strictly prohibited.',
      'Software Integrity: Installing unlicensed software, torrent clients, or unapproved network proxies violates federal copyright law and organizational policy.',
      'Data Privacy: All sensitive student and financial records must be stored exclusively on encrypted organization OneDrive/SharePoint libraries.',
      'Asset Care: Laptops and loaner peripherals must be returned promptly upon semester conclusion or termination of appointment.',
    ],
  },
  {
    id: 'res-glossary',
    title: 'Tech Terms Glossary for Non-Technical Users',
    category: 'Glossary',
    description: 'Plain-English definitions of common computer terminology you see on this support site.',
    content: 'Demystifying technical jargon so you can communicate clearly with technicians.',
    extraList: [
      'RAM (Random Access Memory): The computer’s short-term working memory. Having more RAM allows you to run Word, Excel, and 20 browser tabs at once without stuttering.',
      'SSD (Solid State Drive): The modern, ultra-fast electronic storage drive inside your computer where your files, programs, and Windows operating system live.',
      'VPN (Virtual Private Network): A secure encrypted tunnel connecting your home computer directly to the Charlie Brown campus network as if you were sitting in your office.',
      'Cache (Browser / App Cache): Temporary copies of images and web scripts saved on your drive to speed up loading. When web pages glitch or look broken, clearing the cache fixes 90% of issues.',
      'Phishing: Fraudulent deceptive emails designed by criminals pretending to be trusted organizations to trick you into revealing your password or credit card info.',
      'DNS (Domain Name System): The internet phonebook that translates human names (charliebrown-org.edu) into computer numerical addresses (like 192.168.1.1).',
      'Driver: A small translator program that enables the Windows operating system to talk to hardware like your printer, webcam, or graphics card.',
      'Reboot / Power Cycle: Turning a device off, waiting 30 seconds for capacitors to drain, and turning it back on. Resets hung memory and resolves most temporary errors.',
    ],
  },
  {
    id: 'res-shortcuts',
    title: 'Essential Keyboard Shortcuts Reference Sheet',
    category: 'Shortcuts',
    description: 'Time-saving hotkeys for Windows and Mac that streamline daily tasks and troubleshooting.',
    content: 'Master these everyday shortcuts to work faster and solve common hiccups without touching the mouse.',
    extraList: [
      'Ctrl + Shift + Esc: Instantly open Task Manager (Windows) to see and kill frozen programs',
      'Windows + Ctrl + Shift + B: Emergency graphics card driver reset (wakes frozen or blinking monitors)',
      'Windows + L: Instantly lock your workstation when stepping away from your desk',
      'Windows + V: Opens Clipboard History (view the last 25 text snippets and images you copied)',
      'Windows + Shift + S: Snipping Tool screenshot selector (capture a portion of screen to send to IT)',
      'Ctrl + Z: Undo last mistake / Ctrl + Y: Redo last action in virtually any software application',
      'Ctrl + Shift + T: Reopen the browser tab you just accidentally closed',
      'Alt + Tab (or Cmd + Tab on Mac): Fast switcher between all open application windows',
    ],
  },
];

export const DOWNLOADS: DownloadItem[] = [
  {
    id: 'dl-chrome',
    name: 'Google Chrome',
    officialUrl: 'https://www.google.com/chrome/',
    developer: 'Google LLC',
    category: 'Web Browser',
    os: 'Windows, macOS, Linux',
    licenseType: 'Free Official Software',
    description: 'Fast, secure, and customizable web browser built for modern web applications.',
    itSupportUseCases: 'Standard browser for web applications and cloud services.',
    featured: true,
  },
  {
    id: 'dl-firefox',
    name: 'Mozilla Firefox',
    officialUrl: 'https://www.mozilla.org/firefox/new/',
    developer: 'Mozilla Foundation',
    category: 'Web Browser',
    os: 'Windows, macOS, Linux',
    licenseType: 'Free / Open Source',
    description: 'Privacy-focused open-source web browser with strong tracking protection.',
    itSupportUseCases: 'Alternative high-privacy browser for diagnostic testing and web compatibility.',
    featured: true,
  },
  {
    id: 'dl-7zip',
    name: '7-Zip',
    officialUrl: 'https://www.7-zip.org/',
    developer: 'Igor Pavlov',
    category: 'File Compression',
    os: 'Windows, Linux',
    licenseType: 'Free / Open Source (LGPL)',
    description: 'High-ratio file archiver and compression utility supporting 7z, ZIP, and other archives.',
    itSupportUseCases: 'Essential tool for compressing and decompressing archive files securely.',
    featured: true,
  },
  {
    id: 'dl-powertoys',
    name: 'Microsoft PowerToys',
    officialUrl: 'https://learn.microsoft.com/en-us/windows/powertoys/',
    developer: 'Microsoft Corporation',
    category: 'Productivity Utilities',
    os: 'Windows 11 / 10',
    licenseType: 'Free Official Microsoft Utility',
    description: 'Suite of system tuning and productivity utilities to streamline and customize Windows.',
    itSupportUseCases: 'Window management, shortcut customization, and workflow optimization.',
    featured: true,
  },
  {
    id: 'dl-powershell',
    name: 'Microsoft PowerShell',
    officialUrl: 'https://learn.microsoft.com/en-us/powershell/',
    developer: 'Microsoft Corporation',
    category: 'Automation & Command-Line',
    os: 'Windows, macOS, Linux',
    licenseType: 'Free / Open Source',
    description: 'Cross-platform task automation solution consisting of a command-line shell and scripting language.',
    itSupportUseCases: 'Automating administrative tasks, running diagnostics, and system configuration.',
    featured: true,
  },
];

export const VENDORS: VendorItem[] = [
  {
    id: 'v-microsoft',
    name: 'Microsoft Support',
    category: 'Software & Cloud',
    supportUrl: 'https://support.microsoft.com/',
    phone: '1-800-642-7676',
    hours: '24/7 Online & Phone Support',
    notes: 'Official support for Windows, Microsoft 365 apps, OneDrive, Teams, and organization accounts.',
  },
  {
    id: 'v-apple',
    name: 'Apple Support',
    category: 'Hardware',
    supportUrl: 'https://support.apple.com/',
    phone: '1-800-275-2273',
    hours: '7:00 AM – 10:00 PM PST Daily',
    notes: 'Official support, diagnostics, user manuals, and warranty lookups for Mac, iPad, and macOS.',
  },
  {
    id: 'v-dell',
    name: 'Dell Support',
    category: 'Hardware',
    supportUrl: 'https://www.dell.com/support/',
    phone: '1-800-822-8965',
    hours: '24/7 Technical Support',
    notes: 'Official drivers, diagnostics, and warranty verification for Dell desktop PCs and laptops.',
  },
  {
    id: 'v-hp',
    name: 'HP Support',
    category: 'Printers',
    supportUrl: 'https://support.hp.com/',
    phone: '1-800-474-6836',
    hours: 'Monday – Friday 8:00 AM – 8:00 PM PST',
    notes: 'Official printer drivers, scanning utilities, and troubleshooting documentation for HP hardware.',
  },
  {
    id: 'v-lenovo',
    name: 'Lenovo Support',
    category: 'Hardware',
    supportUrl: 'https://pcsupport.lenovo.com/',
    phone: '1-800-426-7378',
    hours: '24/7 Technical Support',
    notes: 'Official ThinkPad drivers, system updates, and warranty checks for Lenovo devices.',
  },
];

export const INITIAL_TICKETS: SupportTicket[] = [
  {
    ticketId: 'CB-10492',
    fullName: 'Linus van Pelt',
    email: 'lvanpelt@charliebrown-org.edu',
    department: 'Philosophy & Library',
    category: 'Hardware',
    priority: 'Medium',
    subject: 'Monitor display flickering when docking laptop',
    description: 'My secondary Dell 24-inch monitor flickers black for 2 seconds every 15 minutes when connected to the USB-C dock in Room 102.',
    deviceType: 'Dell Latitude 5430',
    assetTag: 'CBO-8921',
    status: 'In Progress',
    createdAt: '2026-09-20 09:14 AM',
    lastUpdated: '2026-09-21 11:30 AM',
    assignedTechnician: 'Sarah Jenkins (Tier 2)',
  },
  {
    ticketId: 'CB-10488',
    fullName: 'Lucy van Pelt',
    email: 'lucy@charliebrown-org.edu',
    department: 'Psychological Services',
    category: 'Software',
    priority: 'Low',
    subject: 'Need SPSS and RStudio installed for research lab',
    description: 'Requested installation of statistical software suite for student research assistants on desktop PCs 4 through 8.',
    deviceType: 'Dell OptiPlex 7090',
    assetTag: 'CBO-5412',
    status: 'Open',
    createdAt: '2026-09-19 02:45 PM',
    lastUpdated: '2026-09-19 02:45 PM',
    assignedTechnician: 'Helpdesk Queue',
  },
  {
    ticketId: 'CB-10475',
    fullName: 'Peppermint Patty',
    email: 'patty@charliebrown-org.edu',
    department: 'Athletics & Kinesiology',
    category: 'Network',
    priority: 'High',
    subject: 'Gymnasium Wi-Fi connection dropping during lecture',
    description: 'The Wi-Fi access point in the east fieldhouse shows limited connectivity whenever more than 20 students join.',
    deviceType: 'Network Access Point',
    assetTag: 'CBO-NET-09',
    status: 'Resolved',
    createdAt: '2026-09-18 10:00 AM',
    lastUpdated: '2026-09-19 04:15 PM',
    assignedTechnician: 'Marcus Vance (Network Admin)',
  },
];
