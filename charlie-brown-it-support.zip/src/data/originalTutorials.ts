import { OriginalTutorial } from '../types';

export const ORIGINAL_TUTORIALS: OriginalTutorial[] = [
  {
    id: 'error-screenshot',
    title: 'How to Capture and Save an Error Screenshot',
    summary:
      'Learn how to quickly capture an unexpected error message using the Windows Snipping Tool, save the image file, and prepare it for an IT support ticket.',
    introduction:
      'When an application crashes or displays an error dialogue, submitting an exact visual capture of the message allows the Charlie Brown IT Support team to pinpoint the error code, DLL name, or system dialog instantly without guesswork. This guide walks you through using the built-in Windows screenshot shortcut, saving the image to your computer, and getting it ready for your support request.',
    category: 'Windows Basics',
    difficulty: 'Beginner',
    estimatedTime: '4 min read',
    iconName: 'Camera',
    whatYouWillLearn: [
      'How to invoke the Windows Snipping Tool using the keyboard shortcut (Win + Shift + S)',
      'How to cleanly crop just the error box or dialog without capturing unrelated windows',
      'How to save the captured image with a descriptive filename in your Pictures folder',
      'How to prepare and attach the saved file to your Charlie Brown IT Support request',
    ],
    requirements: [
      'A computer running Windows 10 or Windows 11',
      'The error dialog or message currently visible on your monitor',
      'Standard keyboard and mouse or trackpad connected',
    ],
    steps: [
      {
        stepNumber: 1,
        title: 'Keep the Error Message Visible on Screen',
        instruction:
          'When the error occurs, do not click "OK", "Cancel", or close the message box immediately. Clicking those buttons may dismiss the error and prevent you from capturing the exact error code.',
        details: [
          'Position other windows so the error message is clearly visible in the center of your screen.',
          'If multiple error dialogs popped up, leave them all on screen.',
        ],
        screenshotPlaceholder: {
          id: 'ss-1-1',
          label: 'Screenshot Placeholder 1.1: Active Error Message Dialog',
          description:
            'Screenshot showing an active Windows error dialog (e.g., "Word encountered an error" with code 0x80070005) centered on the desktop before dismissing.',
          aspectRatio: '16:9',
        },
        caution:
          'Do not press Enter or Escape while the error dialog is in focus, as Windows may register that as closing the dialogue.',
      },
      {
        stepNumber: 2,
        title: 'Launch the Snipping Shortcut (Windows Key + Shift + S)',
        instruction:
          'Press and hold the Windows Key, press Shift, and then press the S key on your keyboard. Release all three keys together.',
        details: [
          'Your monitor will momentarily dim, and a small screenshot toolbar will appear at the top center of your display.',
          'The first button on the toolbar ("Rectangular Snip") is selected by default and is ideal for cropping error boxes.',
        ],
        screenshotPlaceholder: {
          id: 'ss-1-2',
          label: 'Screenshot Placeholder 1.2: Windows Snipping Tool Top Overlay',
          description:
            'Screenshot of the Windows 10/11 Snipping Tool overlay toolbar at the top of the screen showing Rectangular, Freeform, Window, and Fullscreen capture icons.',
          aspectRatio: '16:9',
        },
        proTip:
          'If pressing Win + Shift + S does nothing, click the Windows Start button, type "Snipping Tool", and click "New" to start a capture manually.',
      },
      {
        stepNumber: 3,
        title: 'Click and Drag to Capture the Error Dialog',
        instruction:
          'Move your crosshair cursor just outside the top-left corner of the error box. Click and hold the left mouse button, drag across to the bottom-right corner of the error box, and release.',
        details: [
          'Make sure the title bar of the dialog, the exact error number/code, and all description text fit comfortably inside the highlighted rectangle.',
          'Once you release the mouse button, the selected area will be captured to your Windows clipboard.',
        ],
        screenshotPlaceholder: {
          id: 'ss-1-3',
          label: 'Screenshot Placeholder 1.3: Dragging Selection Box Around Error Window',
          description:
            'Screenshot showing the rectangular selection box drawn around the error dialog while the surrounding background desktop remains dimmed.',
          aspectRatio: '16:9',
        },
      },
      {
        stepNumber: 4,
        title: 'Open the Snipping Notification and Click Save',
        instruction:
          'A rectangular notification toast will appear at the bottom-right corner of your screen stating "Snip saved to clipboard". Click directly on this notification to open the Snipping Tool editor.',
        details: [
          'Inside the Snipping Tool editor, review the image to ensure the error text is sharp and readable.',
          'Click the Floppy Disk / Save icon in the top-right corner of the window (or press Ctrl + S on your keyboard).',
        ],
        screenshotPlaceholder: {
          id: 'ss-1-4',
          label: 'Screenshot Placeholder 1.4: Snipping Tool Editor with Save Icon Highlighted',
          description:
            'Screenshot of the Snipping Tool application interface showing the captured error preview and a red callout ring around the Floppy Disk Save icon.',
          aspectRatio: '16:9',
        },
        proTip:
          'If the notification disappears before you can click it, open Microsoft Paint or an email draft, press Ctrl + V to paste the clipboard image, and save from there.',
      },
      {
        stepNumber: 5,
        title: 'Name the File Descriptively and Choose a Destination',
        instruction:
          'In the "Save As" file browser window, navigate to your "Pictures" or "Desktop" folder so the file is easy to find later.',
        details: [
          'Replace the default generic filename ("Screenshot 2026-...") with a descriptive name, such as "Word_Error_0x80070005_Oct13.png".',
          'Keep the "Save as type" set to PNG (*.png) for clear, non-blurry text quality.',
          'Click the "Save" button.',
        ],
        screenshotPlaceholder: {
          id: 'ss-1-5',
          label: 'Screenshot Placeholder 1.5: Windows File Explorer Save As Dialog',
          description:
            'Screenshot of Windows File Explorer Save As dialog with the Pictures folder selected and a clear descriptive filename entered in the File name input.',
          aspectRatio: '16:9',
        },
      },
      {
        stepNumber: 6,
        title: 'Prepare to Attach to Your IT Support Ticket',
        instruction:
          'Now that your screenshot is saved on your computer, head to the Charlie Brown IT Support "Contact / Support" page to submit your inquiry.',
        details: [
          'Include the screenshot filename and exact error message in your ticket description.',
          'When an IT technician reaches out via email or Helpdesk portal, attach this saved PNG file to provide immediate visual context.',
        ],
        screenshotPlaceholder: {
          id: 'ss-1-6',
          label: 'Screenshot Placeholder 1.6: Charlie Brown Support Ticket Form Reference',
          description:
            'Screenshot of the Charlie Brown IT Support ticket submission form highlighting the Description and Subject inputs with error details added.',
          aspectRatio: '16:9',
        },
      },
    ],
    expectedResult:
      'You have a clean, high-resolution PNG image file saved in your Pictures or Desktop folder that clearly shows the exact error message, ready to be reviewed by a support technician.',
    commonProblems: [
      {
        problem: 'Pressing Windows + Shift + S does not trigger the snipping overlay.',
        solution:
          'Some keyboards have a "Win Lock" key (often labeled with a padlock on the Windows key) that disables the Windows key. Toggle that key off, or launch Snipping Tool directly from the Start Menu.',
      },
      {
        problem: 'The popup notification in the bottom-right corner disappeared too quickly.',
        solution:
          'The captured image is automatically copied to your clipboard. Open Microsoft Paint (Start > Paint), press Ctrl + V to paste it, and save the image from the File menu.',
      },
      {
        problem: 'The error text in the screenshot appears blurry or partially cut off.',
        solution:
          'Repeat steps 2 and 3, ensuring the crosshair begins slightly above and to the left of the error box so no borders or error codes are clipped.',
      },
    ],
    safetyReminders: [
      'Privacy Check: Before sending your screenshot, verify that background browser tabs or desktop windows do not display private personal information, passwords, financial data, or confidential student records.',
      'Cropping Rule: Always crop tightly to the error dialogue rather than capturing your entire dual-monitor desktop whenever possible.',
    ],
    references: [
      {
        title: 'Use Snipping Tool to capture screenshots',
        source: 'Microsoft Support Official Documentation',
        url: 'https://support.microsoft.com/en-us/windows/use-snipping-tool-to-capture-screenshots-00246869-1843-655f-f220-97299b865f6b',
        notes:
          'Official Microsoft technical specification for keyboard shortcuts and image capture formats in Windows 10/11.',
      },
    ],
  },
  {
    id: 'slow-computer-task-manager',
    title: 'How to Check Why Your Computer Is Running Slowly',
    summary:
      'Learn how to open Windows Task Manager, inspect live CPU and memory usage, and safely identify which applications are consuming your computer resources.',
    introduction:
      'A sluggish or unresponsive computer is often caused by a rogue background program hogging processor cycles or running low on available RAM memory. Windows Task Manager provides real-time diagnostics so you can see exactly which program is causing the bottleneck and safely close it before calling the Helpdesk.',
    category: 'Troubleshooting',
    difficulty: 'Beginner',
    estimatedTime: '5 min read',
    iconName: 'Activity',
    whatYouWillLearn: [
      'How to open Windows Task Manager immediately using the Ctrl + Shift + Esc shortcut',
      'How to switch from the minimal view to the full diagnostic Processes table',
      'How to sort running programs by CPU and Memory usage to spot resource hogs',
      'How to safely end an unresponsive application without endangering Windows system files',
    ],
    requirements: [
      'A computer running Windows 10 or Windows 11',
      'Standard user login access (administrator privileges not required for personal app monitoring)',
      'Keyboard and mouse connected',
    ],
    steps: [
      {
        stepNumber: 1,
        title: 'Open Windows Task Manager Instantly (Ctrl + Shift + Esc)',
        instruction:
          'Press and hold the Ctrl and Shift keys with your left hand, then press the Esc key in the top-left corner of your keyboard with your right hand.',
        details: [
          'This three-key combination opens Task Manager immediately without having to navigate through the Windows security screen.',
          'Alternative method: Right-click the Windows Start icon on your taskbar and click "Task Manager" from the pop-up list.',
        ],
        screenshotPlaceholder: {
          id: 'ss-2-1',
          label: 'Screenshot Placeholder 2.1: Opening Task Manager via Quick Shortcut',
          description:
            'Screenshot demonstrating Task Manager launching on screen with the Ctrl + Shift + Esc keyboard shortcut overlay indicator.',
          aspectRatio: '16:9',
        },
      },
      {
        stepNumber: 2,
        title: 'Expand to the Detailed View ("More details")',
        instruction:
          'If Task Manager opens as a small, simple card showing only a list of app names, click the "More details" link (or expand arrow) at the bottom-left corner of the window.',
        details: [
          'This reveals the complete diagnostic table with columns for CPU, Memory, Disk, Network, and GPU usage.',
          'In Windows 11, the view is structured with left-hand navigation tabs; ensure you are on the "Processes" tab (the top icon).',
        ],
        screenshotPlaceholder: {
          id: 'ss-2-2',
          label: 'Screenshot Placeholder 2.2: Task Manager Compact vs. Detailed Processes View',
          description:
            'Side-by-side comparison screenshot showing the compact Task Manager dialog and the full table view after clicking "More details".',
          aspectRatio: '16:9',
        },
      },
      {
        stepNumber: 3,
        title: 'Inspect and Sort by CPU Usage',
        instruction:
          'Locate the "CPU" column header at the top of the processes list. Click once on the word "CPU" to sort the table in descending order so the highest percentage appears at the top.',
        details: [
          'Normal idle behavior: The total CPU usage across the system should typically fluctuate between 2% and 25%.',
          'High utilization indicator: If a single non-essential app (like a web browser or background updater) is constantly utilizing 70% to 100% of your CPU, it is the primary reason your computer feels sluggish.',
        ],
        screenshotPlaceholder: {
          id: 'ss-2-3',
          label: 'Screenshot Placeholder 2.3: Task Manager Sorted by CPU Column',
          description:
            'Screenshot of the Task Manager Processes tab sorted in descending order by the CPU column, showing an app utilizing high CPU highlighted in amber/red.',
          aspectRatio: '16:9',
        },
      },
      {
        stepNumber: 4,
        title: 'Check Memory (RAM) Consumption',
        instruction:
          'Click on the "Memory" column header to sort running programs by their RAM consumption.',
        details: [
          'Web browsers with 30+ open tabs, photo editing software, or virtual meeting tools often consume multiple gigabytes (GB) of RAM.',
          'If the overall Memory bar at the top exceeds 90%, closing unused browser tabs or secondary applications will instantly free up breathing room for your computer.',
        ],
        screenshotPlaceholder: {
          id: 'ss-2-4',
          label: 'Screenshot Placeholder 2.4: Processes Sorted by Memory Column',
          description:
            'Screenshot displaying the Memory column sorted descending, showing browser helper processes consuming significant megabytes/gigabytes of RAM.',
          aspectRatio: '16:9',
        },
      },
      {
        stepNumber: 5,
        title: 'Safely End an Unresponsive or Frozen Application',
        instruction:
          'If a user application shows "(Not Responding)" or is consuming excessive resources without doing any active work: click once on the application name to select it, then click the "End task" button.',
        details: [
          'In Windows 10, "End task" is located in the bottom-right corner of Task Manager.',
          'In Windows 11, "End task" is located in the top command bar.',
          'Give Windows 5 to 10 seconds to terminate the stuck process.',
        ],
        screenshotPlaceholder: {
          id: 'ss-2-5',
          label: 'Screenshot Placeholder 2.5: Selecting App and Clicking End Task',
          description:
            'Screenshot highlighting a frozen user application in the list with a red callout indicator pointing to the "End task" button.',
          aspectRatio: '16:9',
        },
        caution:
          'Safety Rule: Only end applications that you recognize under the "Apps" heading (such as Word, Excel, Chrome, or Teams). Never terminate processes under "Windows processes" (such as System, Explorer, or Host Process) as doing so may cause an abrupt reboot.',
      },
      {
        stepNumber: 6,
        title: 'Verify System Recovery',
        instruction:
          'Observe the overall CPU and Memory percentages at the top of the Task Manager table. If they drop down to normal levels (under 40%), test your system by opening a standard document or browser tab.',
        details: [
          'If performance returns to normal, you may close Task Manager.',
          'If the CPU or Disk continues to stay at 100% despite closing all user apps, save your work and perform a standard reboot (Start > Power > Restart).',
        ],
        screenshotPlaceholder: {
          id: 'ss-2-6',
          label: 'Screenshot Placeholder 2.6: Normalized Task Manager Performance Overview',
          description:
            'Screenshot of the Task Manager Performance tab showing healthy CPU and memory utilization graphs under 30%.',
          aspectRatio: '16:9',
        },
      },
    ],
    expectedResult:
      'You will identify the specific application causing high CPU or memory load, safely terminate it, and restore normal operational speed to your workstation.',
    commonProblems: [
      {
        problem: 'Clicking "End task" results in an "Access is denied" error message.',
        solution:
          'The process is a protected Windows service or campus security agent managed by organization policy. Save any open documents and perform a standard computer restart.',
      },
      {
        problem: 'The Disk column shows 100% usage, but CPU and Memory are low.',
        solution:
          'Windows Update or Windows Defender may be conducting a scheduled background drive integrity check. Allow 15–20 minutes for the scan to conclude before rebooting.',
      },
    ],
    safetyReminders: [
      'Unsaved Data: Forcibly ending a program via "End task" will discard any unsaved edits in that specific application. Only use it when the program is truly frozen and refusing to close normally.',
      'Windows Processes: Avoid touching any background item with a Windows logo or gear icon unless specifically directed by an IT Helpdesk technician.',
    ],
    references: [
      {
        title: 'Using Task Manager in Windows',
        source: 'Microsoft Learn Support Documentation',
        url: 'https://learn.microsoft.com/en-us/troubleshoot/windows-client/performance/use-task-manager-to-troubleshoot',
        notes:
          'Authoritative Microsoft reference for process monitoring and system resource triage.',
      },
    ],
  },
  {
    id: 'clear-stuck-print-job',
    title: 'How to Clear a Stuck Print Job',
    summary:
      'Step-by-step instructions to open Windows printer settings, view your active print queue, cancel a stuck document, and restore normal printing.',
    introduction:
      'When a document is corrupted, contains unsupported fonts, or the printer momentarily loses communication mid-stream, print jobs can get trapped in the Windows print queue. Once a job is stuck, all subsequent documents queued behind it will not print. This guide shows you how to clear the stuck job and resume printing smoothly.',
    category: 'Hardware Support',
    difficulty: 'Beginner',
    estimatedTime: '4 min read',
    iconName: 'Printer',
    whatYouWillLearn: [
      'How to navigate to Windows Printer Settings quickly',
      'How to open and inspect the active Print Queue dialog',
      'How to cancel an individual stuck or "Error - Printing" document',
      'How to send a clean diagnostic test page to confirm the printer is working',
    ],
    requirements: [
      'A computer connected to a local USB desk printer or campus network printer',
      'Printer powered ON with paper loaded in the tray and no flashing error LEDs',
      'Standard Windows user account',
    ],
    steps: [
      {
        stepNumber: 1,
        title: 'Open Windows Printer Settings',
        instruction:
          'Press the Windows Key + I to open Windows Settings. In the left-hand navigation menu, click "Bluetooth & devices", then select "Printers & scanners".',
        details: [
          'Windows will display a list of all printers installed on your computer.',
          'Shortcut: You can also open the Start menu, type "Printers", and press Enter.',
        ],
        screenshotPlaceholder: {
          id: 'ss-3-1',
          label: 'Screenshot Placeholder 3.1: Windows Settings - Printers & Scanners Screen',
          description:
            'Screenshot of the Windows 10/11 Settings app displaying the Printers & Scanners device list with installed campus and local printers.',
          aspectRatio: '16:9',
        },
      },
      {
        stepNumber: 2,
        title: 'Select Your Assigned Printer',
        instruction:
          'Find and click on the name of the printer you are trying to print to (for example, "CharlieBrown-FollowMe-Print" or your designated office printer).',
        details: [
          'Clicking the printer name opens its dedicated management options screen.',
          'Verify that the printer status displays as "Idle" or "Open print queue" rather than "Driver unavailable".',
        ],
        screenshotPlaceholder: {
          id: 'ss-3-2',
          label: 'Screenshot Placeholder 3.2: Dedicated Printer Management Screen',
          description:
            'Screenshot showing the specific printer properties view with the "Open print queue" button prominently displayed.',
          aspectRatio: '16:9',
        },
      },
      {
        stepNumber: 3,
        title: 'Open the Print Queue',
        instruction:
          'Click the "Open print queue" button near the top of the printer management screen.',
        details: [
          'A separate queue window will open, displaying a table with columns for Document Name, Status, Owner, Pages, Size, and Submitted time.',
          'Look for the document at the very top of the list displaying a status such as "Error - Printing", "Deleting...", or "Sent to printer".',
        ],
        screenshotPlaceholder: {
          id: 'ss-3-3',
          label: 'Screenshot Placeholder 3.3: Active Print Queue Window with Stuck File',
          description:
            'Screenshot of the Windows Print Queue dialog window showing a document stuck with the status "Error - Printing" at the top of the list.',
          aspectRatio: '16:9',
        },
      },
      {
        stepNumber: 4,
        title: 'Cancel the Stuck Document',
        instruction:
          'Right-click directly on the stuck document at the top of the queue and select "Cancel" from the context menu.',
        details: [
          'A confirmation box will appear asking: "Are you sure you want to cancel the print job?". Click "Yes".',
          'If there are multiple duplicate jobs queued behind it, you can also click the "Printer" menu at the top left of the queue window and select "Cancel All Documents".',
        ],
        screenshotPlaceholder: {
          id: 'ss-3-4',
          label: 'Screenshot Placeholder 3.4: Right-Clicking Document to Cancel',
          description:
            'Screenshot showing the right-click menu over the stuck document with cursor hovering over the "Cancel" option.',
          aspectRatio: '16:9',
        },
      },
      {
        stepNumber: 5,
        title: 'Wait for the Queue to Clear (or Power Cycle the Printer)',
        instruction:
          'Allow 30 to 60 seconds for Windows to communicate with the printer hardware and flush the spool buffer.',
        details: [
          'The document status may say "Deleting..." briefly before vanishing from the list.',
          'If the job remains stuck after 60 seconds, turn off the physical printer using its power button, wait 15 seconds, and turn it back on. This resets the printer memory cache.',
        ],
        screenshotPlaceholder: {
          id: 'ss-3-5',
          label: 'Screenshot Placeholder 3.5: Empty Print Queue Confirming Cleared Spool',
          description:
            'Screenshot of the Print Queue window showing "0 documents in queue" with a clean white list area.',
          aspectRatio: '16:9',
        },
      },
      {
        stepNumber: 6,
        title: 'Print a Test Page to Verify',
        instruction:
          'Return to the printer management screen in Windows Settings and click "Print test page".',
        details: [
          'If the test page prints properly, your print spooler communication is fully operational.',
          'You may now re-open your original document and send the print job again.',
        ],
        screenshotPlaceholder: {
          id: 'ss-3-6',
          label: 'Screenshot Placeholder 3.6: "Print test page" Button in Windows Settings',
          description:
            'Screenshot showing the "Print test page" link under printer settings with a confirmation notification appearing.',
          aspectRatio: '16:9',
        },
      },
    ],
    expectedResult:
      'The stuck print job is removed from the Windows print queue, the spooler is unlocked, and your printer resumes accepting new print requests normally.',
    commonProblems: [
      {
        problem: 'The document shows "Deleting..." forever and will not leave the queue.',
        solution:
          'Restart the Windows Print Spooler service: Press Windows Key + R, type "services.msc", scroll to "Print Spooler", right-click it, and select "Restart". The stuck job will clear immediately.',
      },
      {
        problem: 'The test page prints, but your original PDF or Word file gets stuck again.',
        solution:
          'The specific file may have corrupted fonts or complex embedded images. In Adobe Acrobat or Word, try choosing "Print as Image" in the advanced print settings.',
      },
    ],
    safetyReminders: [
      'Paper Jam Precaution: If clearing the print queue was triggered by a paper jam, open the printer access door gently and pull trapped paper in the direction of the paper feed path to prevent damaging internal rollers.',
      'Consumables: Check toner and paper levels on the physical printer LCD screen before sending large multi-page print batches.',
    ],
    references: [
      {
        title: 'Fix printer connection and printing problems in Windows',
        source: 'Microsoft Windows Support Official Documentation',
        url: 'https://support.microsoft.com/en-us/windows/fix-printer-problems-in-windows-bf832c0f-0746-48c0-848e-d98c5643440d',
        notes:
          'Official guidelines for clearing print spool queues and troubleshooting print subsystem faults.',
      },
    ],
  },
  {
    id: 'diagnose-reconnect-wifi',
    title: 'How to Diagnose and Reconnect to Wi-Fi',
    summary:
      'Learn how to inspect your wireless network settings, forget and reconnect to the official Charlie Brown Organization network, and verify your connection.',
    introduction:
      'Wireless connectivity problems—such as intermittent signal drops, "No Internet, Secured" alerts, or failure to obtain an IP address—can interrupt coursework and daily office tasks. This tutorial guides you through diagnosing your wireless adapter status, clearing cached network credentials, and re-authenticating with the secure campus network.',
    category: 'Network Support',
    difficulty: 'Beginner',
    estimatedTime: '5 min read',
    iconName: 'Wifi',
    whatYouWillLearn: [
      'How to check Wi-Fi adapter power and Airplane Mode status in Quick Settings',
      'How to connect to the official CharlieBrown-Secure organization network',
      'How to "Forget" a corrupted or expired saved network profile',
      'How to test end-to-end internet connectivity using standard verification tests',
    ],
    requirements: [
      'A laptop, tablet, or desktop equipped with a functional Wi-Fi adapter',
      'Your Charlie Brown Organization email address and active password',
      'Being within physical range of a campus or home Wi-Fi access point',
    ],
    steps: [
      {
        stepNumber: 1,
        title: 'Check the Wi-Fi Status in Windows Quick Settings',
        instruction:
          'Click the cluster of icons (Network, Sound, Battery) in the bottom-right corner of your Windows taskbar, or press the Windows Key + A shortcut.',
        details: [
          'Verify that the Wi-Fi icon is illuminated (turned ON). If it is grayed out, click it once to turn Wi-Fi on.',
          'Verify that "Airplane mode" is turned OFF. If Airplane mode is active, it shuts off all wireless radio antennas.',
        ],
        screenshotPlaceholder: {
          id: 'ss-4-1',
          label: 'Screenshot Placeholder 4.1: Windows Quick Settings Action Center Panel',
          description:
            'Screenshot of the Windows 10/11 Quick Settings flyout panel with Wi-Fi toggled ON in blue and Airplane Mode toggled OFF.',
          aspectRatio: '16:9',
        },
      },
      {
        stepNumber: 2,
        title: 'Select the Official Organization Network',
        instruction:
          'Click the arrow (">") next to the Wi-Fi toggle icon in Quick Settings to view all available networks in range.',
        details: [
          'Select the official organization network: "CharlieBrown-Secure" (or your home network if working remotely).',
          'Check the box labeled "Connect automatically".',
          'Click the "Connect" button.',
        ],
        screenshotPlaceholder: {
          id: 'ss-4-2',
          label: 'Screenshot Placeholder 4.2: Available Wireless Networks List',
          description:
            'Screenshot of the available wireless networks flyout highlighting "CharlieBrown-Secure" with the "Connect automatically" checkbox checked.',
          aspectRatio: '16:9',
        },
        caution:
          'Do not connect to untrusted open networks (such as "Free Public Wi-Fi" or unrecognized hotspots) when handling organizational data.',
      },
      {
        stepNumber: 3,
        title: 'Enter Your Charlie Brown Organization Credentials',
        instruction:
          'When prompted by Windows security, enter your full institutional username (e.g., yourname@charliebrown-org.edu) and your current account password.',
        details: [
          'Do not enter just your firstname; institutional WPA2/WPA3 Enterprise networks require your full organization email identity.',
          'If a prompt appears asking "Continue connecting? Windows cannot verify the server identity", check that the server name indicates charliebrown-org.edu, then click "Connect".',
        ],
        screenshotPlaceholder: {
          id: 'ss-4-3',
          label: 'Screenshot Placeholder 4.3: Windows 802.1X Enterprise Credential Prompt',
          description:
            'Screenshot of the Windows network sign-in prompt requesting User name and Password for campus Enterprise authentication.',
          aspectRatio: '16:9',
        },
      },
      {
        stepNumber: 4,
        title: 'Forget the Network if Authentication Fails',
        instruction:
          'If Windows states "Can\'t connect to this network" or keeps looping on authentication, an outdated password or stale certificate is likely cached.',
        details: [
          'Open Settings (Windows Key + I) > "Network & internet" > "Wi-Fi".',
          'Click "Manage known networks".',
          'Find "CharlieBrown-Secure" in the list and click the "Forget" button next to it.',
          'Once forgotten, return to Step 2 to establish a fresh connection with your current password.',
        ],
        screenshotPlaceholder: {
          id: 'ss-4-4',
          label: 'Screenshot Placeholder 4.4: Windows Settings - Manage Known Networks',
          description:
            'Screenshot of the Manage Known Networks settings page showing the "Forget" button next to saved Wi-Fi network profiles.',
          aspectRatio: '16:9',
        },
      },
      {
        stepNumber: 5,
        title: 'Flush DNS and Renew IP Address (Quick Command)',
        instruction:
          'If you are connected but see "No Internet, Secured", reset your computer\'s network routing table.',
        details: [
          'Press the Windows Key, type "cmd", and press Enter to open the Command Prompt.',
          'Type "ipconfig /flushdns" and press Enter. You will see "Successfully flushed the DNS Resolver Cache".',
          'Next, type "ipconfig /renew" and press Enter to request a fresh IP address from the campus DHCP server.',
        ],
        screenshotPlaceholder: {
          id: 'ss-4-5',
          label: 'Screenshot Placeholder 4.5: Command Prompt Executing ipconfig /flushdns',
          description:
            'Screenshot of the Windows Command Prompt terminal window showing successful execution of ipconfig /flushdns and ipconfig /renew commands.',
          aspectRatio: '16:9',
        },
      },
      {
        stepNumber: 6,
        title: 'Test Your Internet Connection',
        instruction:
          'Open your web browser (Edge, Chrome, or Firefox) and navigate to an external website such as https://charliebrown-org.edu or a search engine.',
        details: [
          'If web pages load immediately and the network icon in your taskbar shows a full solid Wi-Fi arc, your connection is fully functional.',
          'If you still cannot connect, submit a Helpdesk ticket or visit the walk-in counter with your device tag number.',
        ],
        screenshotPlaceholder: {
          id: 'ss-4-6',
          label: 'Screenshot Placeholder 4.6: Successful Web Browser Connectivity Test',
          description:
            'Screenshot of the web browser loading the Charlie Brown IT Support portal confirming active internet connectivity.',
          aspectRatio: '16:9',
        },
      },
    ],
    expectedResult:
      'Your computer establishes an encrypted, authenticated Wi-Fi connection with full internet access and automatic reconnection enabled.',
    commonProblems: [
      {
        problem: 'The Wi-Fi option does not appear at all in Windows Quick Settings or Settings.',
        solution:
          'Your Wi-Fi network card may have entered a power-saving sleep state, or a physical laptop switch was bumped. Check for a physical Wi-Fi toggle on your laptop, or perform a clean restart via Start > Power > Restart.',
      },
      {
        problem: 'You recently changed your campus account password, and Wi-Fi refuses to connect.',
        solution:
          'Windows is still trying to authenticate using your previous password. Use Step 4 to "Forget" the network, then reconnect and enter your new password.',
      },
      {
        problem: 'Signal strength is only 1 bar and disconnects frequently.',
        solution:
          'You may be near the boundary of the access point coverage. Move closer to the nearest indoor access point or hallway ceiling transmitter.',
      },
    ],
    safetyReminders: [
      'Credential Protection: Never share your organization password with classmates or colleagues to let them connect their personal devices.',
      'Encrypted Portals: Always verify the padlock icon in your web browser address bar when logging into campus services over Wi-Fi.',
    ],
    references: [
      {
        title: 'Fix Wi-Fi connection issues in Windows',
        source: 'Microsoft Windows Support Official Documentation',
        url: 'https://support.microsoft.com/en-us/windows/fix-wi-fi-connection-issues-in-windows-9b725511-1b2a-4642-8d13-fe02d51029c9',
        notes:
          'Official troubleshooting instructions for wireless network adapter diagnostic workflows.',
      },
    ],
  },
];
