import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  X,
  HardDrive,
  AppWindow,
  AlertCircle,
  HelpCircle,
  BookOpen,
  Download,
  ArrowRight,
} from 'lucide-react';
import { NavPage } from '../types';
import {
  HARDWARE_ISSUES,
  SOFTWARE_ISSUES,
  TROUBLESHOOTING_TOPICS,
  FAQS,
  TUTORIALS,
  DOWNLOADS,
} from '../data/supportData';
import { ORIGINAL_TUTORIALS } from '../data/originalTutorials';

interface SearchResult {
  id: string;
  title: string;
  category: string;
  categoryType: NavPage;
  snippet: string;
  targetPage: NavPage;
  targetId?: string;
  icon: React.ElementType;
}

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectResult: (page: NavPage, targetId?: string) => void;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({
  isOpen,
  onClose,
  onSelectResult,
}) => {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => {
        inputRef.current?.focus();
      }, 50);
    } else {
      setQuery('');
    }
  }, [isOpen]);

  // Keyboard shortcut Ctrl+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        if (isOpen) {
          onClose();
        } else {
          // Trigger open via parent
        }
      }
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Generate indexed items
  const allItems: SearchResult[] = [
    // Hardware
    ...HARDWARE_ISSUES.map((hw) => ({
      id: hw.id,
      title: hw.title,
      category: 'Hardware Support',
      categoryType: 'hardware' as NavPage,
      snippet: hw.symptoms.join(', ') + ' - ' + hw.quickCheck,
      targetPage: 'hardware' as NavPage,
      targetId: hw.id,
      icon: HardDrive,
    })),
    // Software
    ...SOFTWARE_ISSUES.map((sw) => ({
      id: sw.id,
      title: `${sw.app}: ${sw.title}`,
      category: 'Software Support',
      categoryType: 'software' as NavPage,
      snippet: sw.symptoms.join(', ') + ' - ' + sw.steps[0]?.description,
      targetPage: 'software' as NavPage,
      targetId: sw.id,
      icon: AppWindow,
    })),
    // Troubleshooting
    ...TROUBLESHOOTING_TOPICS.map((tb) => ({
      id: tb.id,
      title: tb.title,
      category: 'Troubleshooting',
      categoryType: 'troubleshooting' as NavPage,
      snippet: tb.commonCauses.join(', ') + ' - ' + tb.primarySteps[0]?.title,
      targetPage: 'troubleshooting' as NavPage,
      targetId: tb.id,
      icon: AlertCircle,
    })),
    // FAQs
    ...FAQS.map((faq) => ({
      id: faq.id,
      title: faq.question,
      category: `FAQ (${faq.category})`,
      categoryType: 'faqs' as NavPage,
      snippet: faq.answer,
      targetPage: 'faqs' as NavPage,
      targetId: faq.id,
      icon: HelpCircle,
    })),
    // Tutorials (Original Team Guides)
    ...ORIGINAL_TUTORIALS.map((tut) => ({
      id: tut.id,
      title: tut.title,
      category: `Tutorials (${tut.category})`,
      categoryType: 'tutorials' as NavPage,
      snippet: tut.summary,
      targetPage: 'tutorials' as NavPage,
      targetId: tut.id,
      icon: BookOpen,
    })),
    // Downloads
    ...DOWNLOADS.map((dl) => ({
      id: dl.id,
      title: dl.name,
      category: `Downloads (${dl.category})`,
      categoryType: 'downloads' as NavPage,
      snippet: dl.description,
      targetPage: 'downloads' as NavPage,
      targetId: dl.id,
      icon: Download,
    })),
  ];

  const q = query.toLowerCase().trim();
  const results = q
    ? allItems.filter(
        (item) =>
          item.title.toLowerCase().includes(q) ||
          item.snippet.toLowerCase().includes(q) ||
          item.category.toLowerCase().includes(q)
      )
    : [];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-start justify-center pt-16 sm:pt-24 px-4 pb-6">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Search Input Box */}
        <div className="flex items-center px-4 py-3.5 border-b border-slate-200 gap-3">
          <Search className="w-5 h-5 text-blue-600 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search all guides, symptoms (e.g., won't turn on, printer offline, Excel, slow)..."
            className="w-full text-slate-900 text-sm focus:outline-hidden placeholder:text-slate-400"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 text-slate-400 hover:text-slate-600 rounded-md"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="px-2 py-1 text-xs font-semibold text-slate-500 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors"
          >
            ESC
          </button>
        </div>

        {/* Popular / Quick Suggestions when empty */}
        {!query && (
          <div className="p-4 sm:p-6 space-y-4">
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2.5">
                Popular Search Terms
              </p>
              <div className="flex flex-wrap gap-2">
                {[
                  'Password reset',
                  'Computer won\'t turn on',
                  'Wi-Fi not working',
                  'Printer offline',
                  'Slow computer',
                  'Excel calculating',
                  'Safe mode',
                  'VPN client',
                  'Clear cache',
                ].map((term) => (
                  <button
                    key={term}
                    onClick={() => setQuery(term)}
                    className="text-xs px-3 py-1.5 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-slate-700 rounded-lg transition-colors border border-slate-200/80"
                  >
                    {term}
                  </button>
                ))}
              </div>
            </div>

            <div className="border-t border-slate-100 pt-4">
              <p className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                Quick Category Jumps
              </p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                <button
                  onClick={() => {
                    onSelectResult('hardware');
                    onClose();
                  }}
                  className="flex items-center gap-2 p-2 rounded-lg hover:bg-slate-50 text-slate-700 text-left border border-slate-100"
                >
                  <HardDrive className="w-4 h-4 text-blue-600" />
                  <span>Hardware Issues</span>
                </button>
                <button
                  onClick={() => {
                    onSelectResult('software');
                    onClose();
                  }}
                  className="flex items-center gap-2 p-2 rounded-lg hover:bg-slate-50 text-slate-700 text-left border border-slate-100"
                >
                  <AppWindow className="w-4 h-4 text-indigo-600" />
                  <span>Software Issues</span>
                </button>
                <button
                  onClick={() => {
                    onSelectResult('troubleshooting');
                    onClose();
                  }}
                  className="flex items-center gap-2 p-2 rounded-lg hover:bg-slate-50 text-slate-700 text-left border border-slate-100"
                >
                  <AlertCircle className="w-4 h-4 text-amber-600" />
                  <span>Troubleshooting</span>
                </button>
                <button
                  onClick={() => {
                    onSelectResult('faqs');
                    onClose();
                  }}
                  className="flex items-center gap-2 p-2 rounded-lg hover:bg-slate-50 text-slate-700 text-left border border-slate-100"
                >
                  <HelpCircle className="w-4 h-4 text-teal-600" />
                  <span>Support FAQs</span>
                </button>
                <button
                  onClick={() => {
                    onSelectResult('tutorials');
                    onClose();
                  }}
                  className="flex items-center gap-2 p-2 rounded-lg hover:bg-slate-50 text-slate-700 text-left border border-slate-100"
                >
                  <BookOpen className="w-4 h-4 text-purple-600" />
                  <span>Step-by-step Tutorials</span>
                </button>
                <button
                  onClick={() => {
                    onSelectResult('downloads');
                    onClose();
                  }}
                  className="flex items-center gap-2 p-2 rounded-lg hover:bg-slate-50 text-slate-700 text-left border border-slate-100"
                >
                  <Download className="w-4 h-4 text-emerald-600" />
                  <span>Software Downloads</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Search Results List */}
        {query && (
          <div className="max-h-[60vh] overflow-y-auto p-2 divide-y divide-slate-100">
            {results.length > 0 ? (
              results.map((res) => {
                const Icon = res.icon;
                return (
                  <button
                    key={`${res.categoryType}-${res.id}`}
                    onClick={() => {
                      onSelectResult(res.targetPage, res.targetId);
                      onClose();
                    }}
                    className="w-full p-3 hover:bg-blue-50/60 rounded-xl text-left transition-colors flex items-start gap-3 group"
                  >
                    <div className="w-8 h-8 rounded-lg bg-blue-100/70 text-blue-700 flex items-center justify-center shrink-0 mt-0.5 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-0.5">
                        <span className="text-[11px] font-semibold uppercase tracking-wider text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200/60">
                          {res.category}
                        </span>
                      </div>
                      <h4 className="text-sm font-semibold text-slate-900 group-hover:text-blue-700 transition-colors">
                        {res.title}
                      </h4>
                      <p className="text-xs text-slate-500 line-clamp-2 mt-0.5">
                        {res.snippet}
                      </p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600 shrink-0 self-center opacity-0 group-hover:opacity-100 transition-opacity" />
                  </button>
                );
              })
            ) : (
              <div className="text-center py-10 px-4">
                <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-400 mb-3">
                  <Search className="w-6 h-6" />
                </div>
                <p className="text-sm font-semibold text-slate-800">
                  No matching support articles found for "{query}"
                </p>
                <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                  Try checking spelling or use broader keywords like "keyboard", "printer", "Word", or "reboot".
                </p>
                <div className="mt-4">
                  <button
                    onClick={() => {
                      onSelectResult('contact');
                      onClose();
                    }}
                    className="text-xs font-semibold text-blue-600 hover:text-blue-700 underline"
                  >
                    Can't find it? Submit an IT Support Ticket &rarr;
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Footer info bar */}
        <div className="px-4 py-2.5 bg-slate-50 border-t border-slate-100 text-[11px] text-slate-500 flex items-center justify-between">
          <span>Charlie Brown IT Knowledgebase</span>
          <span>{allItems.length} indexed topics & guides</span>
        </div>
      </div>
    </div>
  );
};
