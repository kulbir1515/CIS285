import React from 'react';
import {
  Wrench,
  Phone,
  Mail,
  MapPin,
  Clock,
  ExternalLink,
  ShieldCheck,
  LifeBuoy,
} from 'lucide-react';
import { NavPage } from '../types';
import {
  ORG_NAME,
  APP_TITLE,
  HELPDESK_PHONE,
  HELPDESK_EMAIL,
  HELPDESK_HOURS,
  HELPDESK_LOCATION,
} from '../data/supportData';

interface FooterProps {
  onNavigate: (page: NavPage) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="bg-slate-900 text-slate-300 border-t border-slate-800">
      {/* Upper Footer: Emergency & Quick Contact Strip */}
      <div className="border-b border-slate-800/80 bg-slate-950/60 py-6 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <LifeBuoy className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-semibold text-white">
                Urgent Hardware Emergency
              </p>
              <p className="text-xs text-slate-400">
                Call the Help Desk dispatch hotline directly for immediate priority dispatch.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <a
              id="footer-call-hotline"
              href={`tel:${HELPDESK_PHONE.replace(/[^0-9]/g, '')}`}
              className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>Call {HELPDESK_PHONE}</span>
            </a>
            <button
              id="footer-submit-ticket-cta"
              onClick={() => onNavigate('contact')}
              className="inline-flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-100 text-xs font-semibold rounded-lg border border-slate-700 transition-colors"
            >
              <span>Submit Web Ticket</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Footer Links & Info */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Col 1: Brand & Purpose */}
          <div className="space-y-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white">
                <Wrench className="w-4 h-4" />
              </div>
              <span className="font-bold text-base text-white tracking-tight">
                {APP_TITLE}
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Providing accessible, clear, and beginner-friendly technical support resources for students, faculty, and administrative staff at <strong className="text-slate-200">{ORG_NAME}</strong>.
            </p>
            <div className="pt-2 text-xs text-slate-400 space-y-1">
              <p className="font-semibold text-slate-300">Course & Academic Attribution:</p>
              <p>CIS 285 End User Training and Support</p>
              <p className="text-slate-500">University of the Fraser Valley (UFV)</p>
            </div>
          </div>

          {/* Col 2: Support Core Modules */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-3.5">
              Self-Service Hub
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => onNavigate('hardware')}
                  className="hover:text-blue-400 transition-colors text-left"
                >
                  Hardware Support (Power, Display, Keyboard, Mouse, Printer)
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('software')}
                  className="hover:text-blue-400 transition-colors text-left"
                >
                  Software Support (Word, Excel, Browsers, Antivirus)
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('troubleshooting')}
                  className="hover:text-blue-400 transition-colors text-left"
                >
                  Troubleshooting (Slow PC, Freezing, BSOD)
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('tutorials')}
                  className="hover:text-blue-400 transition-colors text-left"
                >
                  Tutorials (Password, MFA, Wi-Fi Setup)
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('faqs')}
                  className="hover:text-blue-400 transition-colors text-left"
                >
                  Frequently Asked Questions (FAQs)
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Resources & Governance */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-3.5">
              Resources & Tools
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => onNavigate('downloads')}
                  className="hover:text-blue-400 transition-colors text-left"
                >
                  Free IT Software & Utilities Catalog
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('vendors')}
                  className="hover:text-blue-400 transition-colors text-left"
                >
                  Authorized Vendor Directory (Dell, Sony, Asus, Acer)
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('contact')}
                  className="hover:text-blue-400 transition-colors text-left"
                >
                  Check Support Ticket Status
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Helpdesk Location & Hours */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-3.5">
              IT Help Desk Office
            </h4>
            <div className="space-y-2 text-xs text-slate-400">
              <div className="flex items-start gap-2">
                <MapPin className="w-3.5 h-3.5 text-blue-400 shrink-0 mt-0.5" />
                <span>{HELPDESK_LOCATION}</span>
              </div>
              <div className="flex items-start gap-2">
                <Clock className="w-3.5 h-3.5 text-blue-400 shrink-0 mt-0.5" />
                <span>{HELPDESK_HOURS}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                <a href={`tel:${HELPDESK_PHONE}`} className="hover:text-white transition-colors">
                  {HELPDESK_PHONE}
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                <a href={`mailto:${HELPDESK_EMAIL}`} className="hover:text-white transition-colors">
                  {HELPDESK_EMAIL}
                </a>
              </div>
            </div>

            <div className="pt-2">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-800 text-slate-300 text-[11px] border border-slate-700">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                Verified Campus IT Portal
              </span>
            </div>
          </div>
        </div>

        {/* Bottom copyright & disclaimer */}
        <div className="mt-10 pt-6 border-t border-slate-800 text-xs text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p>
            &copy; {new Date().getFullYear()} {ORG_NAME}. All technical support resources and trademarks belong to their respective holders.
          </p>
          <div className="flex items-center gap-4 text-[11px]">
            <span>CIS 285 Project (UFV)</span>
            <span>•</span>
            <span>End User Training & Support</span>
            <span>•</span>
            <span>Privacy & Compliance</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
