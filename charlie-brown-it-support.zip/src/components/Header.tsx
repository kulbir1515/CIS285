import React, { useState } from 'react';
import {
  Wrench,
  Search,
  HardDrive,
  AppWindow,
  AlertCircle,
  HelpCircle,
  BookOpen,
  Download,
  Building2,
  Headphones,
  Menu,
  X,
  CheckCircle2,
  PlusCircle,
  Home,
} from 'lucide-react';
import { NavPage } from '../types';
import { ORG_NAME, APP_TITLE } from '../data/supportData';

interface HeaderProps {
  currentPage: NavPage;
  onNavigate: (page: NavPage, targetId?: string) => void;
  onOpenSearch: () => void;
}

const NAV_ITEMS: { id: NavPage; label: string; icon: React.ElementType }[] = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'hardware', label: 'Hardware Support', icon: HardDrive },
  { id: 'software', label: 'Software Support', icon: AppWindow },
  { id: 'troubleshooting', label: 'Troubleshooting', icon: AlertCircle },
  { id: 'faqs', label: 'FAQs', icon: HelpCircle },
  { id: 'tutorials', label: 'Tutorials', icon: BookOpen },
  { id: 'downloads', label: 'Downloads', icon: Download },
  { id: 'vendors', label: 'Vendor Support', icon: Building2 },
  { id: 'contact', label: 'Contact / Support', icon: Headphones },
];

export const Header: React.FC<HeaderProps> = ({
  currentPage,
  onNavigate,
  onOpenSearch,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNavClick = (page: NavPage) => {
    onNavigate(page);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-xs">
      {/* Top Organization Header Bar */}
      <div className="bg-slate-900 text-slate-100 text-xs py-1.5 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="font-semibold tracking-wide text-blue-300">
              {ORG_NAME}
            </span>
            <span className="text-slate-500 hidden sm:inline">•</span>
            <span className="text-slate-300 hidden sm:inline">
              CIS 285 End User Training & Support • UFV
            </span>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5 text-emerald-400">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <span className="font-medium text-[11px] text-slate-200">
                IT Systems: <span className="text-emerald-300">Operational</span>
              </span>
            </div>
            <span className="text-slate-600 hidden md:inline">|</span>
            <span className="text-slate-300 hidden md:inline">
              Help Desk: (555) 242-7543
            </span>
          </div>
        </div>
      </div>

      {/* Primary Brand & Actions Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3">
        <div className="flex items-center justify-between gap-4">
          {/* Logo & Portal Title */}
          <button
            id="brand-home-button"
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-3 text-left focus:outline-hidden group"
          >
            <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-xs group-hover:bg-blue-700 transition-colors">
              <Wrench className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="text-lg font-bold tracking-tight text-slate-900 group-hover:text-blue-600 transition-colors">
                {APP_TITLE}
              </div>
              <div className="text-xs text-slate-500 font-medium">
                Official Tech Support Portal
              </div>
            </div>
          </button>

          {/* Search Trigger Button */}
          <div className="hidden md:flex flex-1 max-w-md mx-6">
            <button
              id="header-search-bar"
              onClick={onOpenSearch}
              className="w-full flex items-center justify-between px-3.5 py-2 text-sm text-slate-500 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors shadow-xs"
            >
              <div className="flex items-center gap-2">
                <Search className="w-4 h-4 text-slate-400" />
                <span>Search support guides, errors, hardware...</span>
              </div>
              <kbd className="hidden lg:inline-block px-2 py-0.5 text-[11px] font-semibold text-slate-500 bg-white border border-slate-200 rounded shadow-2xs">
                Ctrl + K
              </kbd>
            </button>
          </div>

          {/* Quick Actions & Mobile Hamburger */}
          <div className="flex items-center gap-2.5">
            <button
              id="mobile-search-button"
              onClick={onOpenSearch}
              className="md:hidden p-2 text-slate-600 hover:text-blue-600 hover:bg-slate-100 rounded-lg transition-colors"
              aria-label="Open Search"
            >
              <Search className="w-5 h-5" />
            </button>

            <button
              id="submit-ticket-header-button"
              onClick={() => handleNavClick('contact')}
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-2xs transition-colors"
            >
              <PlusCircle className="w-4 h-4" />
              <span className="hidden sm:inline">Submit Ticket</span>
              <span className="sm:hidden">Ticket</span>
            </button>

            <button
              id="mobile-menu-toggle"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>
          </div>
        </div>

        {/* Desktop Horizontal Navigation (All 10 Items) */}
        <nav className="hidden lg:flex items-center gap-1 mt-2.5 pt-2 border-t border-slate-100 overflow-x-auto no-scrollbar">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            return (
              <button
                key={item.id}
                id={`nav-link-${item.id}`}
                onClick={() => handleNavClick(item.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold tracking-normal whitespace-nowrap transition-colors ${
                  isActive
                    ? 'text-blue-700 bg-blue-50 border border-blue-200/60'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/80 border border-transparent'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-blue-600' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-6 space-y-1 shadow-lg max-h-[80vh] overflow-y-auto">
          <div className="mb-3 px-2">
            <p className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Support Navigation
            </p>
          </div>
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            return (
              <button
                key={item.id}
                id={`mobile-nav-link-${item.id}`}
                onClick={() => handleNavClick(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium transition-colors text-left ${
                  isActive
                    ? 'bg-blue-50 text-blue-700 font-semibold'
                    : 'text-slate-700 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-blue-600' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </div>
                {isActive && <CheckCircle2 className="w-4 h-4 text-blue-600" />}
              </button>
            );
          })}
          <div className="pt-4 mt-2 border-t border-slate-100 flex flex-col gap-2">
            <div className="p-3 bg-slate-50 rounded-lg text-xs text-slate-600">
              <span className="font-semibold text-slate-900 block mb-0.5">Need immediate assistance?</span>
              Call the IT Helpdesk at <span className="font-bold text-blue-700">(555) 242-7543</span> or visit Charlie Brown Hall, Suite 204.
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
