# Charlie Brown IT Support Portal

> **Course:** CIS 285 – End User Training and Support  
> **Institution:** University of the Fraser Valley (UFV)  
> **Client / Organization:** The Charlie Brown Organization  
> **Application:** Charlie Brown IT Support & Help Desk Portal  

---

## 📌 Project Overview

This comprehensive technical support and troubleshooting web portal was engineered for **The Charlie Brown Organization** as part of the **CIS 285: End User Training and Support** course at the **University of the Fraser Valley (UFV)**.

The portal is designed to bridge the gap between non-technical end users and technical support staff. By offering accessible self-service diagnostic guides, direct links to vetted external software utilities, curated online learning resources, transparent vendor contact information, and an integrated work-order ticketing dispatch system, the platform reduces tier-1 repetitive helpdesk tickets while improving end-user digital autonomy and productivity.

---

## 🎯 Core Features & System Modules

### 1. Hardware Support
- Comprehensive troubleshooting modules for common hardware failures:
  - Computer Won't Turn On / Power Failure
  - Keyboard & Typing Issues
  - Mouse & Pointer Malfunctions
  - Monitor / External Display & Docking Issues
  - Printer, Spooler & Follow-Me Printing Hiccups
  - Audio, Microphone & Speaker Issues
  - USB Device & Peripheral Recognition
  - Wi-Fi Adapters & Campus Network Connectivity
- Includes fast 10-second checks, symptom checklists, sequential step guides, technician pro-tips, and escalation paths.

### 2. Software & Application Support
- Structured self-help guides for essential software suites:
  - Microsoft Word (corrupt templates, auto-recovery, crashes)
  - Microsoft Excel (circular references, formula calculation mode, frozen sheets)
  - Microsoft PowerPoint (slide show dual-monitor display, font/video embedding)
  - Web Browsers (Chrome, Edge, Firefox cache clearing, extension conflicts)
  - Email Applications (Microsoft Outlook profile sync, offline errors)
  - Antivirus & Security (Windows Security scans, quarantined file review)
  - Operating System Issues (Windows/macOS stuck updates, reboot loops)
  - Software Installation & Uninstallation (prerequisite libraries, permissions)

### 3. Central Troubleshooting Hub & Interactive Diagnostic Wizard
- Priority-ranked deep-dive workflows for high-impact problems:
  - Slow Computer & Memory Leaks
  - Internet Disconnections & DNS Flushes
  - System Freezing & Deadlocks
  - Blue Screen of Death (BSOD) Bugcheck Triage
  - Hard Drive Storage Exhaustion
  - Overheating, Thermal Throttling & Fan Noise
- An interactive **Guided Diagnostic Wizard** that triages symptoms through a step-by-step decision tree to provide targeted solutions and escalation advice.

### 4. Vetted Utility Downloads (For IT Workers & End Users)
- Curated list of genuine, free diagnostic and maintenance utilities linking directly to official vendor sites (`target="_blank"`):
  - **7-Zip** (`7-zip.org`): High-ratio open source file archiver.
  - **Malwarebytes** (`malwarebytes.com`): Premier anti-malware and adware scanner.
  - **CCleaner** (`ccleaner.com`): System cleaner and temporary file purger.
  - **TeamViewer** (`teamviewer.com`): Cross-platform remote assistance tool.
  - **Speccy** (`ccleaner.com/speccy`): Detailed hardware specification and temperature utility.
  - **Revo Uninstaller** (`revouninstaller.com`): Thorough software uninstaller with registry and remnant cleanup.
  - **Wireshark** (`wireshark.org`): Open-source network packet inspection tool.
  - **Process Explorer** (`learn.microsoft.com`): Advanced Sysinternals task manager replacement.
  - **TreeSize Free** (`jam-software.com`): Disk space visualization and analyzer.

### 5. Curated Online Tutorials & Training Resources
- Real, working external links to authoritative training repositories for popular software:
  - **GCFGlobal (`edu.gcfglobal.org`)**: Beginner-friendly tutorials for computer basics, Windows, and Office.
  - **Microsoft Learn (`learn.microsoft.com`)**: Official interactive learning paths for M365, Word, Excel, Teams, and Windows.
  - **Adobe Support & Tutorials (`helpx.adobe.com`)**: Official video walkthroughs for Photoshop, Acrobat, and Creative Cloud.
  - **Google Workspace Learning Center (`support.google.com/a/users`)**: Guides for Docs, Sheets, Drive, and Gmail.
  - **Apple Support (`support.apple.com`)**: macOS essentials and navigation guides.
  - **Zoom Learning Center (`learning.zoom.us`)**: Video conferencing setup, audio troubleshooting, and moderation.
  - **Canva Design School (`canva.com`)**: Visual presentations and graphics tutorials.
  - **W3Schools (`w3schools.com`)**: Beginner web technology and coding fundamentals.

### 6. Authorized Vendor Directory
- Enterprise contact details, support hotlines, business hours, and direct warranty/service-tag portals for:
  - Dell Technologies
  - HP Customer Support
  - Lenovo ThinkPad
  - Microsoft
  - Cisco / Meraki
  - Apple Care
  - Brother International
  - Zoom Video Communications
  - **Sony Electronics** (`sony.com/electronics/support`)
  - **ASUS** (`asus.com/support`)
  - **Acer** (`acer.com/support`, covering legacy Gateway)

### 7. Interactive Helpdesk Work Orders & Ticket Status Tracking
- Responsive support request form generating unique tracking IDs (e.g., `CB-10492`).
- Self-service **Ticket Status Checker** to look up technician notes, urgency, and live resolution progress.
- Walk-in desk location, telephone hotlines, and monitored hours.

### 8. IT Quick Assistant & Global Search
- Real-time client-side virtual assistant answering common end-user inquiries.
- Global modal search (`Ctrl+K` / `Cmd+K`) indexing all topics, hardware components, FAQs, utilities, and tutorials.

---

## 💻 Tech Stack

- **Framework:** React 18 with TypeScript
- **Styling:** Tailwind CSS with responsive, accessible layout and typography
- **Icons:** Lucide React
- **Build Tool:** Vite
- **Architecture:** Client-side Single Page Application (SPA) with zero external API key requirements.

---

## 🏫 Academic Attribution

- **Course:** CIS 285 – End User Training and Support
- **Department:** Department of Computer Information Systems
- **University:** University of the Fraser Valley (UFV), Abbotsford / Chilliwack, British Columbia, Canada
- **Project:** Charlie Brown IT Support Portal
